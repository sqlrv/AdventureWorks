/*============================================================================
  File:     pg_install_awdb_01.sql

  Summary:  Creates the AdventureWorks sample database for Postgres. Run this
  script on any version of Postgres (11 or later) to get AdventureWorks for your
  current version.  

  Date:     September 6, 2024
  Updated:  

------------------------------------------------------------------------------
  This file is derived from the Microsoft SQL Server Code Samples.

  Copyright (c) Aaron N. Cutshall.  All rights reserved.

  This source code is intended only as a supplement to Postgres development
  and is intended only as an example database.  Original version obtained
  from Microsoft GitHub site:
  https://github.com/microsoft/sql-server-samples/tree/master/samples/databases/adventure-works/oltp-install-script

  All data in this database is ficticious.
  
  THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
  KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
  IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
============================================================================*/

--
-- Stop the script on any error
--
\SET ON_ERROR_STOP ON

--
-- Drop the AdventureWorks database if it exists
--
DROP DATABASE IF EXISTS AdventureWorks;

--
-- Create the AdventureWorks database, add a comment, then connect to it
--
CREATE DATABASE AdventureWorks;
\CONNECT AdventureWorks

--
-- Create the default schema to match SQL Server's default
--
CREATE SCHEMA dbo;
ALTER DATABASE AdventureWorks SET SEARCH_PATH TO dbo;