/*============================================================================
  File:     pg_install_awdb_01.sql

  Summary:  Creates the AdventureWorks sample database for Postgres. Run this
  script on any version of Postgres (11 or later) to get AdventureWorks for your
  current version.  

  Date:     November 25, 2023
  Updated:  

------------------------------------------------------------------------------
  This file is derived from the Microsoft SQL Server Code Samples.

  Copyright (c) Aaron N. Cutshall.  All rights reserved.

  This source code is intended only as a supplement to Postgres development
  and is intended only as an example database.  Original version obtained
  from Microsoft GitHub site:
  https://github.com/microsoft/sql-server-samples/tree/master/samples/databases/adventure-works/oltp-install-script

  All data in this database is ficticious.
  
  THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
  KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
  IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
============================================================================*/

--
-- Stop the script on any error
--
\set ON_ERROR_STOP on

--
-- Drop the AdventureWorks database if it exists
--
drop database if exists "AdventureWorks";

--
-- Create the AdventureWorks database, add a comment, then connect to it
--
create database "AdventureWorks";
comment on database "AdventureWorks" is 'Migration of AdventureWorks from SQL Server to Postgres.';
\connect "AdventureWorks"

--
-- Create the schemas necessary to match the original in AdventureWorks
--
create schema "dbo";
comment on schema "dbo" is 'Database Owner schema to correspond with the default schema created on SQL Server.';

create schema "HumanResources";
comment on schema "HumanResources" is 'Schema for objects related to Human Resources.';

create schema "Person";
comment on schema "Person" is 'Schema for objects related to a Person.';

create schema "Production";
comment on schema "Production" is 'Schema for objects related to Production.';

create schema "Sales";
comment on schema "Sales" is 'Schema for objects related to Sales.';
