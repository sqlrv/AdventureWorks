/*============================================================================
  File:     pg_install_awdb_05.sql

  Summary:  Creates the AdventureWorks sample database for Postgres. Run this
  script on any version of Postgres (11 or later) to get AdventureWorks for your
  current version.  

  Date:     September 6, 2024
  Updated:  

------------------------------------------------------------------------------
  This file is derived from the Microsoft SQL Server Code Samples.

  Copyright (c) Aaron N. Cutshall.  All rights reserved.

  This source code is intended only as a supplement to Postgres development
  and is intended only as an example database.  Original version obtained
  from Microsoft GitHub site:
  https://github.com/microsoft/sql-server-samples/tree/master/samples/databases/adventure-works/oltp-install-script

  All data in this database is ficticious.
  
  THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
  KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
  IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
============================================================================*/

--
-- Stop the script on any error
--
\SET ON_ERROR_STOP ON

--
-- Drop the AdventureWorks database if it exists
--
DROP DATABASE IF EXISTS AdventureWorks;

--
-- Create the AdventureWorks database, add a comment, then connect to it
--
CREATE DATABASE AdventureWorks;
\CONNECT AdventureWorks

--
-- Create the schemas necessary to match the original in AdventureWorks
--
CREATE SCHEMA dbo;
ALTER DATABASE AdventureWorks SET SEARCH_PATH TO dbo;

-- Create the extension to handle GUID/UUID values
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
-- Create the extension to handle hash values
CREATE EXTENSION IF NOT EXISTS pgcrypto;
-- Create the extension to handle heirarchical trees
CREATE EXTENSION IF NOT EXISTS ltree;

-- ******************************************************
-- Create Error Trapping
-- ******************************************************

-- Create table to store error information
CREATE TABLE dbo.ErrorLog (
	ErrorLogID int GENERATED AS IDENTITY PRIMARY KEY NOT NULL,
	ErrorTime timestamp NOT NULL DEFAULT (now()),
	UserName text NOT NULL,
	ErrorNumber text NOT NULL,
	ErrorSeverity text NULL,
	ErrorState text NULL,
	ErrorProcedure text NULL,
	ErrorLine int NULL,
	ErrorMessage text NOT NULL
	);

CREATE UNIQUE INDEX PK_ErrorLog_ErrorLogID ON dbo.ErrorLog(ErrorLogID);


-- uspPrintError prints error information about the error that caused 
-- execution to jump to the EXCEPTION block. Calls to GET DIAGNOSTICS
-- and GET STACKED DIAGNOSTICS are required to obtain the values for
-- the parameters of this function.
CREATE PROCEDURE dbo.uspPrintError (pg_context text, pg_sqlstate text)
	LANGUAGE PLPGSQL
	IMMUTABLE
	SECURITY DEFINER
AS $$
DECLARE
	v_pg_context text;
BEGIN
	-- Print error information.
	v_pg_context = split_part(pg_context, chr(10), 2);

	RAISE NOTICE 'error code = %', pg_sqlstate;
	RAISE NOTICE 'error text = %', split_part(pg_context, chr(10), 1);
	RAISE NOTICE 'procedure  = %', split_part(v_pg_context, ' ', 3);
	RAISE NOTICE 'line nbr   = %', split_part(v_pg_context, ' ', 5);
	RAISE NOTICE 'full error = %', pg_context;
END;
$$

-- uspLogError logs error information in the ErrorLog table about the
-- error that caused execution to jump to the EXCEPTION block of a
-- procedure. This should be executed from within the scope of the
-- EXCEPTION block, otherwise it will return without inserting error
-- information.
CREATE PROCEDURE dbo.uspLogError(pg_context text, pg_sqlstate text)
	RETURNS int
	LANGUAGE PLPGSQL
	STABLE
	SECURITY DEFINER
AS $procedure$
DECLARE
	v_pg_context text;
	v_pg_sqlstate text;
	v_pg_errorlogid int;
BEGIN
	-- Return if there is no error information to log
	IF pg_context IS NULL THEN
		RETURN;
	ELSE
		v_pg_context = split_part(pg_context, chr(10), 2);
		INSERT dbo.ErrorLog (
			UserName,
			ErrorNumber,
			ErrorSeverity,
			ErrorProcedure,
			ErrorLine,
			ErrorMessage
			)
		VALUES (
			CURRENT_USER,
			pg_sqlstate,
			split_part(pg_context, chr(10), 1),
			split_part(v_pg_context, ' ', 3),
			split_part(v_pg_context, ' ', 5),
			pg_context
			)
		RETURNING ErrorLogID INTO v_pg_errorlogid;
		RETURN;
	END IF;
EXCEPTION
	GET STACKED DIAGNOSTICS v_pg_context = pg_exception_context,
							v_pg_sqlstate = returned_sqlstate;
	RAISE NOTICE 'An error occurred in function fn_log_error:';
	CALL dbo.uspPrintError v_pg_context, v_pg_sqlstate;
END;
$procedure$

-- ******************************************************
-- Add pre-table database functions.
-- ******************************************************
CREATE FUNCTION dbo.ufnLeadingZeros(int)
	RETURNS varchar(8)
	LANGUAGE SQL
	IMMUTABLE
AS $function$
	SELECT RIGHT(REPEAT('0',8)||$1::varchar(8),8);
$function$

-- ******************************************************
-- Create Additional Schemas
-- ******************************************************
CREATE SCHEMA HumanResources;
CREATE SCHEMA Person;
CREATE SCHEMA Production;
CREATE SCHEMA Purchasing;
CREATE SCHEMA Sales;

-- ******************************************************
-- Create Data Types
-- ******************************************************
CREATE DOMAIN d_AccountNumber FROM varchar(15) NULL;
CREATE DOMAIN d_Flag FROM boolean NOT NULL;
CREATE DOMAIN d_NameStyle FROM boolean NOT NULL;
CREATE DOMAIN d_Name FROM varchar(50) NULL;
CREATE DOMAIN d_OrderNumber FROM varchar(25) NULL;
CREATE DOMAIN d_Phone FROM varchar(25) NULL;

-- ******************************************************
-- Create tables
-- ******************************************************
CREATE TABLE dbo.xml_schema_collection (
	db_schema_name varchar(128) NOT NULL,
	collection_name varchar(128) NOT NULL,
	target_namespace varchar(128) NOT NULL,
	xsd_value xml NOT NULL
	);

CREATE TABLE Person.Address (
	AddressID int GENERATED BY DEFAULT AS IDENTITY,
	AddressLine1 varchar(60) NOT NULL,
	AddressLine2 varchar(60) NULL,
	City varchar(30) NOT NULL,
	StateProvinceID int NOT NULL,
	PostalCode varchar(15) NOT NULL,
	SpatialLocation geography NULL, -- Representing longitude and latitude
	rowguid uuid NOT NULL DEFAULT gen_random_uuid(), -- constraint name ignored as defaults are not constraints in Postgres
	ModifiedDate timestamp NOT NULL DEFAULT now()
	);

CREATE TABLE Person.AddressType (
	AddressTypeID int GENERATED BY DEFAULT AS IDENTITY,
	Name d_Name,
	rowguid uuid NOT NULL DEFAULT gen_random_uuid(),
	ModifiedDate timestamp NOT NULL DEFAULT now()
	);

CREATE TABLE dbo.AWBuildVersion (
	SystemInformationID smallint GENERATED BY DEFAULT AS IDENTITY,
	DatabaseVersion varchar(25) NOT NULL,
	VersionDate timestamp NOT NULL,
	ModifiedDate timestamp NOT NULL DEFAULT now()
	);

CREATE TABLE Production.BillOfMaterials (
	BillOfMaterialsID int GENERATED BY DEFAULT AS IDENTITY,
	ProductAssemblyID int NULL,
	ComponentID int NOT NULL,
	StartDate timestamp NOT NULL DEFAULT now(),
	EndDate timestamp NULL CONSTRAINT CK_BillOfMaterials_EndDate CHECK ((EndDate > StartDate) OR (EndDate IS NULL)),
	UnitMeasureCode char(3) NOT NULL,
	BOMLevel smallint NOT NULL,
	PerAssemblyQty numeric(8, 2) NOT NULL CONSTRAINT CK_BillOfMaterials_PerAssemblyQty CHECK (PerAssemblyQty >= 1.00) DEFAULT 1.00,
	ModifiedDate timestamp NOT NULL DEFAULT now(),
	CONSTRAINT CK_BillOfMaterials_ProductAssemblyID CHECK (ProductAssemblyID <> ComponentID),
	CONSTRAINT CK_BillOfMaterials_BOMLevel CHECK (((ProductAssemblyID IS NULL)
		AND (BOMLevel = 0) AND (PerAssemblyQty = 1.00)) 
		OR ((ProductAssemblyID is NOT NULL) AND (BOMLevel >= 1)))
	);

CREATE TABLE Person.BusinessEntity (
	BusinessEntityID int GENERATED BY DEFAULT AS IDENTITY,
	rowguid uuid NOT NULL DEFAULT gen_random_uuid(),
	ModifiedDate timestamp NOT NULL DEFAULT now()
	);

CREATE TABLE Person.BusinessEntityAddress (
	BusinessEntityID int NOT NULL,
	AddressID int NOT NULL,
	AddressTypeID int NOT NULL,
	rowguid uuid NOT NULL DEFAULT gen_random_uuid(),
	ModifiedDate timestamp NOT NULL DEFAULT now()
	);

CREATE TABLE Person.BusinessEntityContact (
	BusinessEntityID int NOT NULL,
	PersonID int NOT NULL,
	ContactTypeID int NOT NULL,
	rowguid uuid NOT NULL DEFAULT gen_random_uuid(),
	ModifiedDate timestamp NOT NULL DEFAULT now()
	);

CREATE TABLE Person.ContactType (
	ContactTypeID int GENERATED BY DEFAULT AS IDENTITY,
	Name d_Name,
	ModifiedDate timestamp NOT NULL DEFAULT now()
	);

CREATE TABLE Sales.CountryRegionCurrency (
	CountryRegionCode varchar(3) NOT NULL,
	CurrencyCode char(3) NOT NULL,
	ModifiedDate timestamp NOT NULL DEFAULT now()
	);

CREATE TABLE Person.CountryRegion (
	CountryRegionCode varchar(3) NOT NULL,
	Name d_Name,
	ModifiedDate timestamp NOT NULL DEFAULT now()
	);

CREATE TABLE Sales.CreditCard (
	CreditCardID int GENERATED BY DEFAULT AS IDENTITY,
	CardType varchar(50) NOT NULL,
	CardNumber varchar(25) NOT NULL,
	ExpMonth smallint NOT NULL,
	ExpYear smallint NOT NULL,
	ModifiedDate timestamp NOT NULL DEFAULT now()
	);

CREATE TABLE Production.Culture (
	CultureID char(6) NOT NULL,
	Name d_Name, 
	ModifiedDate timestamp NOT NULL DEFAULT now()
	);

CREATE TABLE Sales.Currency (
	CurrencyCode char(3) NOT NULL,
	Name d_Name,
	ModifiedDate timestamp NOT NULL DEFAULT now()
	);

CREATE TABLE Sales.CurrencyRate (
	CurrencyRateID int GENERATED BY DEFAULT AS IDENTITY,
	CurrencyRateDate timestamp NOT NULL,
	FromCurrencyCode char(3) NOT NULL,
	ToCurrencyCode char(3) NOT NULL,
	AverageRate numeric(20,4) NOT NULL,
	EndOfDayRate numeric(20,4) NOT NULL, 
	ModifiedDate timestamp NOT NULL DEFAULT now()
	);

CREATE TABLE Sales.Customer (
	CustomerID int GENERATED BY DEFAULT AS IDENTITY,
	-- A customer may either be a person, a store, or a person who works for a store
	PersonID int NULL, -- If this customer represents a person, this is non-NULL
	StoreID int NULL,  -- If the customer is a store, or is associated with a store then this is non-NULL.
	TerritoryID int NULL,
	AccountNumber char(10) NULL GENERATED ALWAYS AS (coalesce('AW' || dbo.ufnLeadingZeros(CustomerID), '')) stored,
	rowguid uuid NOT NULL DEFAULT gen_random_uuid(),
	ModifiedDate timestamp NOT NULL DEFAULT now()
	);

CREATE TABLE HumanResources.Department (
	DepartmentID smallint GENERATED BY DEFAULT AS IDENTITY,
	Name d_Name,
	GroupName d_Name,
	ModifiedDate timestamp NOT NULL DEFAULT now()
	);

CREATE TABLE Production.Document (
	DocumentNode ltree NOT NULL,
	DocumentLevel int NOT NULL GENERATED ALWAYS AS (NLEVEL(DocumentNode)) STORED,
	Title varchar(50) NOT NULL,
	Owner int NOT NULL,
	FolderFlag boolean NOT NULL DEFAULT false,
	FileName varchar(400) NOT NULL,
	FileExtension varchar(8) NOT NULL,
	Revision char(5) NOT NULL,
	ChangeNumber int NOT NULL DEFAULT 0,
	Status smallint NOT NULL CONSTRAINT CK_Document_Status CHECK (Status BETWEEN 1 AND 3),
	DocumentSummary text NULL,
	Document bytea NULL,
	rowguid uuid NOT NULL DEFAULT gen_random_uuid(),
	ModifiedDate timestamp NOT NULL DEFAULT now()
	);

CREATE TABLE Person.EmailAddress (
	BusinessEntityID int NOT NULL,
	EmailAddressID int GENERATED BY DEFAULT AS IDENTITY,
	EmailAddress varchar(50) NULL,
	rowguid uuid NOT NULL DEFAULT gen_random_uuid(),
	ModifiedDate timestamp NOT NULL DEFAULT now()
	);

CREATE TABLE HumanResources.Employee (
	BusinessEntityID int NOT NULL,
	NationalIDNumber varchar(15) NOT NULL,
	LoginID varchar(256) NOT NULL,
	OrganizationNode ltree NULL,
	OrganizationLevel int NOT NULL GENERATED ALWAYS AS (NLEVEL(OrganizationNode)) STORED,
	JobTitle varchar(50) NOT NULL,
	BirthDate date NOT NULL CONSTRAINT CK_Employee_BirthDate CHECK (BirthDate BETWEEN '1930-01-01'::date AND (current_date - interval '18 years')::date),
	MaritalStatus char(1) NOT NULL CONSTRAINT CK_Employee_MaritalStatus CHECK (to_upper(MaritalStatus) IN ('M', 'S')), -- Married or Single
	Gender char(1) NOT NULL CONSTRAINT CK_Employee_Gender CHECK (to_upper(Gender) IN ('M', 'F')), -- Male or Female
	HireDate date NOT NULL CONSTRAINT CK_Employee_HireDate CHECK (HireDate BETWEEN '1996-07-01'::date AND (current_date + interval '1 day')::date),
	SalariedFlag d_Flag DEFAULT true,
	VacationHours smallint NOT NULL CONSTRAINT CK_Employee_VacationHours CHECK (VacationHours BETWEEN -40 AND 240) DEFAULT 0,
	SickLeaveHours smallint NOT NULL CONSTRAINT CK_Employee_SickLeaveHours CHECK (SickLeaveHours BETWEEN 0 AND 120) DEFAULT 0,
	CurrentFlag d_Flag DEFAULT true,
	rowguid uuid NOT NULL DEFAULT gen_random_uuid(),
	ModifiedDate timestamp NOT NULL DEFAULT now()
	);

CREATE TABLE HumanResources.EmployeeDepartmentHistory (
	BusinessEntityID int NOT NULL,
	DepartmentID smallint NOT NULL,
	ShiftID smallint NOT NULL,
	StartDate date NOT NULL,
	EndDate date NULL CONSTRAINT CK_EmployeeDepartmentHistory_EndDate CHECK ((EndDate >= StartDate) OR (EndDate IS NULL)),
	ModifiedDate timestamp NOT NULL DEFAULT now()
	);

CREATE TABLE HumanResources.EmployeePayHistory (
	BusinessEntityID int NOT NULL,
	RateChangeDate timestamp NOT NULL,
	Rate numeric(20,4) NOT NULL CONSTRAINT CK_EmployeePayHistory_Rate CHECK (Rate BETWEEN 6.50 AND 200.00),
	PayFrequency smallint NOT NULL CONSTRAINT CK_EmployeePayHistory_PayFrequency CHECK (PayFrequency IN (1, 2)), -- 1 = monthly salary, 2 = biweekly salary
	ModifiedDate timestamp NOT NULL DEFAULT now()
	);

CREATE TABLE Production.Illustration (
	IllustrationID int GENERATED BY DEFAULT AS IDENTITY,
	Diagram xml NULL,
	ModifiedDate timestamp NOT NULL DEFAULT now()
	);

CREATE TABLE HumanResources.JobCandidate (
	JobCandidateID int GENERATED BY DEFAULT AS IDENTITY,
	BusinessEntityID int NULL,
	Resume xml NULL, -- HumanResources.HRResumeSchemaCollection
	ModifiedDate timestamp NOT NULL DEFAULT now()
	);

CREATE TABLE Production.Location (
	LocationID smallint GENERATED BY DEFAULT AS IDENTITY,
	Name d_Name,
	CostRate numeric(10,4) NOT NULL CONSTRAINT CK_Location_CostRate CHECK (CostRate >= 0.00) DEFAULT (0.00),
	Availability numeric(8,2) NOT NULL CONSTRAINT CK_Location_Availability CHECK (Availability >= 0.00) DEFAULT (0.00), 
	ModifiedDate timestamp NOT NULL DEFAULT now()
	);

CREATE TABLE Person.Password (
	BusinessEntityID int NOT NULL,
	PasswordHash varchar(128) NOT NULL,
	PasswordSalt varchar(10) NOT NULL,
	rowguid uuid NOT NULL DEFAULT gen_random_uuid(),
	ModifiedDate timestamp NOT NULL DEFAULT now()
	);

CREATE TABLE Person.Person (
	BusinessEntityID int NOT NULL,
	PersonType char(2) NOT NULL CONSTRAINT CK_Person_PersonType CHECK (PersonType IS NULL OR to_upper(PersonType) IN ('SC', 'VC', 'IN', 'EM', 'SP', 'GC')),
	NameStyle d_NameStyle NOT NULL DEFAULT false,
	Title varchar(8) NULL, 
	FirstName d_Name,
	MiddleName d_Name NULL,
	LastName d_Name,
	Suffix varchar(10) NULL, 
	EmailPromotion int NOT NULL CONSTRAINT CK_Person_EmailPromotion CHECK (EmailPromotion BETWEEN 0 AND 2) DEFAULT (0),
	AdditionalContactInfo xml NULL, -- Person.AdditionalContactInfoSchemaCollection
	Demographics xml NULL, -- Person.IndividualSurveySchemaCollection
	rowguid uuid NOT NULL DEFAULT gen_random_uuid(),
	ModifiedDate timestamp NOT NULL DEFAULT now()
	);

CREATE TABLE Sales.PersonCreditCard (
	BusinessEntityID int NOT NULL,
	CreditCardID int NOT NULL,
	ModifiedDate timestamp NOT NULL DEFAULT now()
	);

CREATE TABLE Person.PersonPhone (
	BusinessEntityID int NOT NULL,
	PhoneNumber d_Phone NOT NULL,
	PhoneNumberTypeID int NOT NULL,
	ModifiedDate timestamp NOT NULL DEFAULT now()
	);

CREATE TABLE Person.PhoneNumberType (
	PhoneNumberTypeID int GENERATED BY DEFAULT AS IDENTITY,
	Name d_Name,
	ModifiedDate timestamp NOT NULL DEFAULT now()
	);

CREATE TABLE Production.Product (
	ProductID int GENERATED BY DEFAULT AS IDENTITY,
	Name d_Name,
	ProductNumber varchar(25) NOT NULL,
	MakeFlag d_Flag default true,
	FinishedGoodsFlag d_Flag default true,
	Color varchar(15) NULL,
	SafetyStockLevel smallint NOT NULL CONSTRAINT CK_Product_SafetyStockLevel CHECK (SafetyStockLevel > 0),
	ReorderPoint smallint NOT NULL CONSTRAINT CK_Product_ReorderPoint CHECK (ReorderPoint > 0),
	StandardCost numeric(20,4) NOT NULL CONSTRAINT CK_Product_StandardCost CHECK (StandardCost >= 0.00),
	ListPrice numeric(20,4) NOT NULL CONSTRAINT CK_Product_ListPrice CHECK (ListPrice >= 0.00),
	Size nvarchar(5) NULL,
	SizeUnitMeasureCode char(3) NULL,
	WeightUnitMeasureCode char(3) NULL,
	Weight numeric(8, 2) NULL CONSTRAINT CK_Product_Weight CHECK (Weight > 0.00),
	DaysToManufacture int NOT NULL CONSTRAINT CK_Product_DaysToManufacture CHECK (DaysToManufacture >= 0),
	ProductLine char(2) NULL CONSTRAINT CK_Product_ProductLine CHECK (to_upper(ProductLine) IN ('S', 'T', 'M', 'R') OR ProductLine IS NULL),
	Class char(2) NULL CONSTRAINT CK_Product_Class CHECK (to_upper(Class) IN ('L', 'M', 'H') OR Class IS NULL),
	Style char(2) NULL CONSTRAINT CK_Product_Style CHECK (to_upper(Style) IN ('W', 'M', 'U') OR Style IS NULL), 
	ProductSubcategoryID int NULL,
	ProductModelID int NULL,
	SellStartDate timestamp NOT NULL,
	SellEndDate timestamp NULL CONSTRAINT CK_Product_SellEndDate CHECK ((SellEndDate >= SellStartDate) OR (SellEndDate IS NULL)),
	DiscontinuedDate timestamp NULL,
	rowguid uuid NOT NULL DEFAULT gen_random_uuid(),
	ModifiedDate timestamp NOT NULL DEFAULT now()
	);

CREATE TABLE Production.ProductCategory (
	ProductCategoryID int GENERATED BY DEFAULT AS IDENTITY,
	Name d_Name,
	rowguid uuid NOT NULL DEFAULT gen_random_uuid(),
	ModifiedDate timestamp NOT NULL DEFAULT now()
	);

CREATE TABLE Production.ProductCostHistory (
	ProductID int NOT NULL,
	StartDate timestamp NOT NULL,
	EndDate timestamp NULL CONSTRAINT CK_ProductCostHistory_EndDate CHECK ((EndDate >= StartDate) OR (EndDate IS NULL)),
	StandardCost numeric(20,4) NOT NULL CONSTRAINT CK_ProductCostHistory_StandardCost CHECK (StandardCost >= 0.00),
	ModifiedDate timestamp NOT NULL DEFAULT now()
	);

CREATE TABLE Production.ProductDescription (
	ProductDescriptionID int GENERATED BY DEFAULT AS IDENTITY,
	Description varchar(400) NOT NULL,
	rowguid uuid NOT NULL DEFAULT gen_random_uuid(),
	ModifiedDate timestamp NOT NULL DEFAULT now()
	);

CREATE TABLE Production.ProductDocument (
	ProductID int NOT NULL,
	DocumentNode ltree NOT NULL,
	ModifiedDate timestamp NOT NULL DEFAULT now()
	);

CREATE TABLE Production.ProductInventory (
	ProductID int NOT NULL,
	LocationID smallint NOT NULL,
	Shelf varchar(10) NOT NULL CONSTRAINT CK_ProductInventory_Shelf CHECK ((Shelf LIKE 'A-Za-z') OR (Shelf = 'N/A')),
	Bin smallint NOT NULL CONSTRAINT CK_ProductInventory_Bin CHECK (Bin BETWEEN 0 AND 100),
	Quantity smallint NOT NULL DEFAULT (0),
	rowguid uuid NOT NULL DEFAULT gen_random_uuid(),
	ModifiedDate timestamp NOT NULL DEFAULT now()
	);

CREATE TABLE Production.ProductListPriceHistory (
	ProductID int NOT NULL,
	StartDate timestamp NOT NULL,
	EndDate timestamp NULL CONSTRAINT CK_ProductListPriceHistory_EndDate CHECK ((EndDate >= StartDate) OR (EndDate IS NULL)),
	ListPrice numeric(20,4) NOT NULL CONSTRAINT CK_ProductListPriceHistory_ListPrice CHECK (ListPrice > 0.00),
	ModifiedDate timestamp DEFAULT now()
	);

CREATE TABLE Production.ProductModel (
	ProductModelID int GENERATED BY DEFAULT AS IDENTITY,
	Name d_Name,
	CatalogDescription xml NULL, -- Production.ProductDescriptionSchemaCollection
	Instructions xml NULL, -- Production.ManuInstructionsSchemaCollection
	rowguid uuid NOT NULL DEFAULT gen_random_uuid(),
	ModifiedDate timestamp NOT NULL DEFAULT now()
	);

CREATE TABLE Production.ProductModelIllustration (
	ProductModelID int NOT NULL,
	IllustrationID int NOT NULL,
	ModifiedDate timestamp NOT NULL DEFAULT now()
	);

CREATE TABLE Production.ProductModelProductDescriptionCulture (
	ProductModelID int NOT NULL,
	ProductDescriptionID int NOT NULL,
	CultureID char(6) NOT NULL,
	ModifiedDate timestamp NOT NULL DEFAULT now()
	);

CREATE TABLE Production.ProductPhoto (
	ProductPhotoID int GENERATED BY DEFAULT AS IDENTITY,
	ThumbNailPhoto bytea NULL,
	ThumbnailPhotoFileName varchar(50) NULL,
	LargePhoto bytea NULL,
	LargePhotoFileName varchar(50) NULL,
	ModifiedDate timestamp NOT NULL DEFAULT now()
	);

CREATE TABLE Production.ProductProductPhoto (
	ProductID int NOT NULL,
	ProductPhotoID int NOT NULL,
	Primary d_Flag default false,
	ModifiedDate timestamp NOT NULL DEFAULT now()
	);

CREATE TABLE Production.ProductReview (
	ProductReviewID int GENERATED BY DEFAULT AS IDENTITY,
	ProductID int NOT NULL,
	ReviewerName d_Name,
	ReviewDate timestamp NOT NULL DEFAULT now(),
	EmailAddress varchar(50) NOT NULL,
	Rating int NOT NULL CONSTRAINT CK_ProductReview_Rating CHECK (Rating BETWEEN 1 AND 5),
	Comments varchar(3850), 
	ModifiedDate timestamp NOT NULL DEFAULT now()
	);

CREATE TABLE Production.ProductSubcategory (
	ProductSubcategoryID int GENERATED BY DEFAULT AS IDENTITY,
	ProductCategoryID int NOT NULL,
	Name d_Name,
	rowguid uuid NOT NULL DEFAULT gen_random_uuid(),
	ModifiedDate timestamp NOT NULL DEFAULT now()
	);
CREATE TABLE Purchasing.ProductVendor (
	ProductID int NOT NULL,
	BusinessEntityID int NOT NULL,
	AverageLeadTime int NOT NULL CONSTRAINT CK_ProductVendor_AverageLeadTime CHECK (AverageLeadTime >= 1),
	StandardPrice numeric(20,4) NOT NULL CONSTRAINT CK_ProductVendor_StandardPrice CHECK (StandardPrice > 0.00),
	LastReceiptCost numeric(20,4) NULL CONSTRAINT CK_ProductVendor_LastReceiptCost CHECK (LastReceiptCost > 0.00),
	LastReceiptDate timestamp NULL,
	MinOrderQty int NOT NULL CONSTRAINT CK_ProductVendor_MinOrderQty CHECK (MinOrderQty >= 1),
	MaxOrderQty int NOT NULL CONSTRAINT CK_ProductVendor_MaxOrderQty CHECK (MaxOrderQty >= 1),
	OnOrderQty int NULL CONSTRAINT CK_ProductVendor_OnOrderQty CHECK (OnOrderQty >= 0),
	UnitMeasureCode char(3) NOT NULL,
	ModifiedDate timestamp NOT NULL DEFAULT now()
	);

CREATE TABLE Purchasing.PurchaseOrderDetail (
	PurchaseOrderID int NOT NULL,
	PurchaseOrderDetailID int GENERATED BY DEFAULT AS IDENTITY,
	DueDate timestamp NOT NULL,
	OrderQty smallint NOT NULL CONSTRAINT CK_PurchaseOrderDetail_OrderQty CHECK (OrderQty > 0),
	ProductID int NOT NULL,
	UnitPrice numeric(20,4) NOT NULL CONSTRAINT CK_PurchaseOrderDetail_UnitPrice CHECK (UnitPrice >= 0.00),
	LineTotal numeric(20,4) GENERATED ALWAYS AS (COALESCE(OrderQty::numeric * UnitPrice, 0.00)) STORED,
	ReceivedQty numeric(8,2) NOT NULL CONSTRAINT CK_PurchaseOrderDetail_ReceivedQty CHECK (ReceivedQty >= 0.00),
	RejectedQty numeric(8,2) NOT NULL CONSTRAINT CK_PurchaseOrderDetail_RejectedQty CHECK (RejectedQty >= 0.00),
	StockedQty numeric(8,2) GENERATED ALWAYS AS (COALESCE(ReceivedQty - RejectedQty, 0.00)) STORED,
	ModifiedDate timestamp NOT NULL DEFAULT now()
	);

CREATE TABLE Purchasing.PurchaseOrderHeader (
	PurchaseOrderID int GENERATED BY DEFAULT AS IDENTITY,
	RevisionNumber smallint NOT NULL DEFAULT 0,
	Status smallint NOT NULL DEFAULT 1 CONSTRAINT CK_PurchaseOrderHeader_Status CHECK (Status between 1 and 4), -- 1 = Pending; 2 = Approved; 3 = Rejected; 4 = Complete
	EmployeeID int NOT NULL,
	VendorID int NOT NULL,
	ShipMethodID int NOT NULL,
	OrderDate timestamp NOT NULL DEFAULT now(),
	ShipDate timestamp NULL CONSTRAINT CK_PurchaseOrderHeader_ShipDate CHECK ((ShipDate >= OrderDate) OR (ShipDate IS NULL)),
	SubTotal numeric(20,4) NOT NULL DEFAULT 0.00 CONSTRAINT CK_PurchaseOrderHeader_SubTotal CHECK (SubTotal >= 0.00),
	TaxAmt numeric(20,4) NOT NULL DEFAULT 0.00 CONSTRAINT CK_PurchaseOrderHeader_TaxAmt CHECK (TaxAmt >= 0.00),
	Freight numeric(20,4) NOT NULL DEFAULT (0.00) CONSTRAINT CK_PurchaseOrderHeader_Freight CHECK (Freight >= 0.00),
	TotalDue numeric(20,4) NOT NULL GENERATED ALWAYS AS (COALESCE(SubTotal + TaxAmt + Freight, 0)) STORED,
	ModifiedDate timestamp NOT NULL DEFAULT now()
	);

CREATE TABLE Sales.SalesOrderDetail (
	SalesOrderID int NOT NULL,
	SalesOrderDetailID int GENERATED BY DEFAULT AS IDENTITY,
	CarrierTrackingNumber varchar(25) NULL,
	OrderQty smallint NOT NULL CONSTRAINT CK_SalesOrderDetail_OrderQty CHECK (OrderQty > 0),
	ProductID int NOT NULL,
	SpecialOfferID int NOT NULL,
	UnitPrice numeric(20,4) NOT NULL CONSTRAINT CK_SalesOrderDetail_UnitPrice CHECK (UnitPrice >= 0.00),
	UnitPriceDiscount numeric(20,4) NOT NULL DEFAULT 0.0 CONSTRAINT CK_SalesOrderDetail_UnitPriceDiscount CHECK (UnitPriceDiscount >= 0.00),
	LineTotal numeric(20,4) GENERATED ALWAYS AS (COALESCE(UnitPrice * (1.0 - UnitPriceDiscount) * OrderQty, 0.0)) stored,
	rowguid uuid NOT NULL DEFAULT gen_random_uuid(),
	ModifiedDate timestamp NOT NULL DEFAULT now()
	);

CREATE TABLE Sales.SalesOrderHeader (
	SalesOrderID int GENERATED BY DEFAULT AS IDENTITY,
	RevisionNumber smallint NOT NULL DEFAULT 0,
	OrderDate timestamp NOT NULL DEFAULT now(),
	DueDate timestamp NOT NULL CONSTRAINT CK_SalesOrderHeader_DueDate CHECK (DueDate >= OrderDate),
	ShipDate timestamp NULL CONSTRAINT CK_SalesOrderHeader_ShipDate CHECK ((ShipDate >= OrderDate) OR (ShipDate IS NULL)),
	Status smallint NOT NULL DEFAULT 1 CONSTRAINT CK_SalesOrderHeader_Status CHECK (Status BETWEEN 0 AND 8),
	OnlineOrderFlag d_Flag DEFAULT true,
	SalesOrderNumber d_OrderNumber GENERATED ALWAYS AS (COALESCE('SO' || SalesOrderID::varchar(23), '*** ERROR ***')),
	PurchaseOrderNumber d_OrderNumber,
	AccountNumber d_AccountNumber,
	CustomerID int NOT NULL,
	SalesPersonID int NULL,
	TerritoryID int NULL,
	BillToAddressID int NOT NULL,
	ShipToAddressID int NOT NULL,
	ShipMethodID int NOT NULL,
	CreditCardID int NULL,
	CreditCardApprovalCode varchar(15) NULL,
	CurrencyRateID int NULL,
	SubTotal numeric(20,4) NOT NULL DEFAULT (0.00) CONSTRAINT CK_SalesOrderHeader_SubTotal CHECK (SubTotal >= 0.00),
	TaxAmt numeric(20,4) NOT NULL DEFAULT (0.00) CONSTRAINT CK_SalesOrderHeader_TaxAmt CHECK (TaxAmt >= 0.00),
	Freight numeric(20,4) NOT NULL DEFAULT (0.00) CONSTRAINT CK_SalesOrderHeader_Freight CHECK (Freight >= 0.00),
	TotalDue numeric(20,4) GENERATED ALWAYS AS (COALESCE(SubTotal + TaxAmt + Freight, 0)),
	Comment varchar(128) NULL,
	rowguid uuid NOT NULL DEFAULT gen_random_uuid(),
	ModifiedDate timestamp NOT NULL DEFAULT now()
	);

CREATE TABLE Sales.SalesOrderHeaderSalesReason (
	SalesOrderID int NOT NULL,
	SalesReasonID int NOT NULL,
	ModifiedDate timestamp NOT NULL DEFAULT now()
	);

CREATE TABLE Sales.SalesPerson (
	BusinessEntityID int NOT NULL,
	TerritoryID int NULL,
	SalesQuota numeric(20,4) NULL CONSTRAINT CK_SalesPerson_SalesQuota CHECK (SalesQuota > 0.00),
	Bonus numeric(20,4) NOT NULL DEFAULT (0.00) CONSTRAINT CK_SalesPerson_Bonus CHECK (Bonus >= 0.00),
	CommissionPct numeric(20,4) NOT NULL DEFAULT (0.00) CONSTRAINT CK_SalesPerson_CommissionPct CHECK (CommissionPct >= 0.00),
	SalesYTD numeric(20,4) NOT NULL DEFAULT (0.00) CONSTRAINT CK_SalesPerson_SalesYTD CHECK (SalesYTD >= 0.00),
	SalesLastYear numeric(20,4) NOT NULL DEFAULT (0.00) CONSTRAINT CK_SalesPerson_SalesLastYear CHECK (SalesLastYear >= 0.00),
	rowguid uuid NOT NULL DEFAULT gen_random_uuid(),
	ModifiedDate timestamp NOT NULL DEFAULT now()
	);

CREATE TABLE Sales.SalesPersonQuotaHistory (
	BusinessEntityID int NOT NULL,
	QuotaDate timestamp NOT NULL,
	SalesQuota numeric(20,4) NOT NULL DEFAULT (0.00) CONSTRAINT CK_SalesPersonQuotaHistory_SalesQuota CHECK (SalesQuota > 0.00),
	rowguid uuid NOT NULL DEFAULT gen_random_uuid(),
	ModifiedDate timestamp NOT NULL DEFAULT now()
	);

CREATE TABLE Sales.SalesReason (
	SalesReasonID int GENERATED BY DEFAULT AS IDENTITY,
	Name d_Name,
	ReasonType d_Name,
	ModifiedDate timestamp NOT NULL DEFAULT now()
	);

CREATE TABLE Sales.SalesTaxRate (
	SalesTaxRateID int GENERATED BY DEFAULT AS IDENTITY,
	StateProvinceID int NOT NULL,
	TaxType smallint NOT NULL CONSTRAINT CK_SalesTaxRate_TaxType CHECK (TaxType BETWEEN 1 AND 3),
	TaxRate numeric(15,6) NOT NULL DEFAULT (0.00),
	Name d_Name,
	rowguid uuid NOT NULL DEFAULT gen_random_uuid(),
	ModifiedDate timestamp NOT NULL DEFAULT now()
	);

CREATE TABLE Sales.SalesTerritory (
	TerritoryID int GENERATED BY DEFAULT AS IDENTITY,
	Name d_Name,
	CountryRegionCode varchar(3) NOT NULL,
	Group varchar(50) NOT NULL,
	SalesYTD numeric(20,4) NOT NULL DEFAULT (0.00) CONSTRAINT CK_SalesTerritory_SalesYTD CHECK (SalesYTD >= 0.00),
	SalesLastYear numeric(20,4) NOT NULL DEFAULT (0.00) CONSTRAINT CK_SalesTerritory_SalesLastYear CHECK (SalesLastYear >= 0.00),
	CostYTD numeric(20,4) NOT NULL DEFAULT (0.00) CONSTRAINT CK_SalesTerritory_CostYTD CHECK (CostYTD >= 0.00),
	CostLastYear numeric(20,4) NOT NULL DEFAULT (0.00) CONSTRAINT CK_SalesTerritory_CostLastYear CHECK (CostLastYear >= 0.00),
	rowguid uuid NOT NULL DEFAULT gen_random_uuid(),
	ModifiedDate timestamp NOT NULL DEFAULT now()
	);

CREATE TABLE Sales.SalesTerritoryHistory (
	BusinessEntityID int NOT NULL, -- A sales person
	TerritoryID int NOT NULL,
	StartDate timestamp NOT NULL,
	EndDate timestamp NULL CONSTRAINT CK_SalesTerritoryHistory_EndDate CHECK ((EndDate >= StartDate) OR (EndDate IS NULL)),
	rowguid uuid NOT NULL DEFAULT gen_random_uuid(),
	ModifiedDate timestamp NOT NULL DEFAULT now()
	);

CREATE TABLE Production.ScrapReason (
	ScrapReasonID smallint GENERATED BY DEFAULT AS IDENTITY,
	Name d_Name,
	ModifiedDate timestamp NOT NULL DEFAULT now()
	);

CREATE TABLE HumanResources.Shift (
	ShiftID smallint GENERATED BY DEFAULT AS IDENTITY,
	Name d_Name,
	StartTime time NOT NULL,
	EndTime time NOT NULL,
	ModifiedDate timestamp NOT NULL DEFAULT now()
	);

CREATE TABLE Purchasing.ShipMethod (
	ShipMethodID int GENERATED BY DEFAULT AS IDENTITY,
	Name d_Name,
	ShipBase numeric(20,4) NOT NULL DEFAULT (0.00) CONSTRAINT CK_ShipMethod_ShipBase CHECK (ShipBase > 0.00),
	ShipRate numeric(20,4) NOT NULL DEFAULT (0.00) CONSTRAINT CK_ShipMethod_ShipRate CHECK (ShipRate > 0.00),
	rowguid uuid NOT NULL DEFAULT gen_random_uuid(),
	ModifiedDate timestamp NOT NULL DEFAULT now()
	);

CREATE TABLE Sales.ShoppingCartItem (
	ShoppingCartItemID int GENERATED BY DEFAULT AS IDENTITY,
	ShoppingCartID varchar(50) NOT NULL,
	Quantity int NOT NULL DEFAULT (1) CONSTRAINT CK_ShoppingCartItem_Quantity CHECK (Quantity >= 1),
	ProductID int NOT NULL,
	DateCreated timestamp NOT NULL DEFAULT now(), 
	ModifiedDate timestamp NOT NULL DEFAULT now()
	);

CREATE TABLE Sales.SpecialOffer (
	SpecialOfferID int GENERATED BY DEFAULT AS IDENTITY,
	Description varchar(255) NOT NULL,
	DiscountPct numeric(15,6) NOT NULL DEFAULT (0.00) CONSTRAINT CK_SpecialOffer_DiscountPct CHECK (DiscountPct >= 0.00),
	Type varchar(50) NOT NULL,
	Category varchar(50) NOT NULL,
	StartDate timestamp NOT NULL,
	EndDate timestamp NOT NULL CONSTRAINT CK_SpecialOffer_EndDate CHECK (EndDate >= StartDate),
	MinQty int NOT NULL DEFAULT (0) CONSTRAINT CK_SpecialOffer_MinQty CHECK (MinQty >= 0), 
	MaxQty int NULL CONSTRAINT CK_SpecialOffer_MaxQty CHECK (MaxQty >= 0),
	rowguid uuid NOT NULL DEFAULT gen_random_uuid(),
	ModifiedDate timestamp NOT NULL DEFAULT now()
	);

CREATE TABLE Sales.SpecialOfferProduct (
	SpecialOfferID int NOT NULL,
	ProductID int NOT NULL,
	rowguid uuid NOT NULL DEFAULT gen_random_uuid(),
	ModifiedDate timestamp NOT NULL DEFAULT now()
	);

CREATE TABLE Person.StateProvince (
	StateProvinceID int GENERATED BY DEFAULT AS IDENTITY,
	StateProvinceCode char(3) NOT NULL,
	CountryRegionCode varchar(3) NOT NULL,
	IsOnlyStateProvinceFlag d_Flag DEFAULT (1),
	Name d_Name,
	TerritoryID int NOT NULL,
	rowguid uuid NOT NULL DEFAULT gen_random_uuid(),
	ModifiedDate timestamp NOT NULL DEFAULT now()
	);

CREATE TABLE Sales.Store (
	BusinessEntityID int NOT NULL,
	Name d_Name,
	SalesPersonID int NULL,
	Demographics xml NULL, -- Sales.StoreSurveySchemaCollection
	rowguid uuid NOT NULL DEFAULT gen_random_uuid(),
	ModifiedDate timestamp NOT NULL DEFAULT now()
	);

CREATE TABLE Production.TransactionHistory (
	TransactionID int GENERATED BY DEFAULT AS IDENTITY,
	ProductID int NOT NULL,
	ReferenceOrderID int NOT NULL,
	ReferenceOrderLineID int NOT NULL DEFAULT (0),
	TransactionDate timestamp NOT NULL DEFAULT now(),
	TransactionType char(1) NOT NULL CONSTRAINT CK_TransactionHistory_TransactionType CHECK (to_upper(TransactionType) IN ('W', 'S', 'P')),
	Quantity int NOT NULL,
	ActualCost numeric(20,4) NOT NULL,
	ModifiedDate timestamp NOT NULL DEFAULT now()
	);

CREATE TABLE Production.TransactionHistoryArchive (
	TransactionID int NOT NULL,
	ProductID int NOT NULL,
	ReferenceOrderID int NOT NULL,
	ReferenceOrderLineID int NOT NULL DEFAULT (0),
	TransactionDate timestamp NOT NULL DEFAULT now(),
	TransactionType char(1) NOT NULL CONSTRAINT CK_TransactionHistoryArchive_TransactionType CHECK (to_upper(TransactionType) IN ('W', 'S', 'P')),
	Quantity int NOT NULL,
	ActualCost numeric(20,4) NOT NULL,
	ModifiedDate timestamp NOT NULL DEFAULT now()
	);

CREATE TABLE Production.UnitMeasure (
	UnitMeasureCode char(3) NOT NULL,
	Name d_Name,
	ModifiedDate timestamp NOT NULL DEFAULT now()
	);

CREATE TABLE Purchasing.Vendor (
	BusinessEntityID int NOT NULL,
	AccountNumber d_AccountNumber NOT NULL,
	Name d_Name,
	CreditRating smallint NOT NULL CONSTRAINT CK_Vendor_CreditRating CHECK (CreditRating BETWEEN 1 AND 5),
	PreferredVendorStatus d_Flag default true,
	ActiveFlag d_Flag DEFAULT true,
	PurchasingWebServiceURL varchar(1024) NULL,
	ModifiedDate timestamp NOT NULL DEFAULT now()
	);

CREATE TABLE Production.WorkOrder (
	WorkOrderID int GENERATED BY DEFAULT AS IDENTITY,
	ProductID int NOT NULL,
	OrderQty int NOT NULL CONSTRAINT CK_WorkOrder_OrderQty CHECK (OrderQty > 0),
	StockedQty int generated always as (coalesce(OrderQty - ScrappedQty, 0)),
	ScrappedQty smallint NOT NULL CONSTRAINT CK_WorkOrder_ScrappedQty CHECK (ScrappedQty >= 0),
	StartDate timestamp NOT NULL,
	EndDate timestamp NULL CONSTRAINT CK_WorkOrder_EndDate CHECK ((EndDate >= StartDate) OR (EndDate IS NULL)),
	DueDate timestamp NOT NULL,
	ScrapReasonID smallint NULL,
	ModifiedDate timestamp NOT NULL DEFAULT now()
	);

CREATE TABLE Production.WorkOrderRouting (
	WorkOrderID int NOT NULL,
	ProductID int NOT NULL,
	OperationSequence smallint NOT NULL,
	LocationID smallint NOT NULL,
	ScheduledStartDate timestamp NOT NULL,
	ScheduledEndDate timestamp NOT NULL CONSTRAINT CK_WorkOrderRouting_ScheduledEndDate CHECK (ScheduledEndDate >= ScheduledStartDate),
	ActualStartDate timestamp NULL,
	ActualEndDate timestamp NULL CONSTRAINT CK_WorkOrderRouting_ActualEndDate CHECK ((ActualEndDate >= ActualStartDate) OR (ActualEndDate IS NULL) OR (ActualStartDate IS NULL)),
	ActualResourceHrs numeric(9,4) NULL CONSTRAINT CK_WorkOrderRouting_ActualResourceHrs CHECK (ActualResourceHrs >= 0.0000),
	PlannedCost numeric(20,4) NOT NULL CONSTRAINT CK_WorkOrderRouting_PlannedCost CHECK (PlannedCost > 0.00),
	ActualCost numeric(20,4) NULL CONSTRAINT CK_WorkOrderRouting_ActualCost CHECK (ActualCost > 0.00),
	ModifiedDate timestamp NOT NULL DEFAULT now()
	);

-- ******************************************************
-- Load data
-- ******************************************************

INSERT INTO dbo.schema_collection (db_schema_name, collection_name, target_namespace, db_xsd_value)
	VALUES (('Person', 'AdditionalContactInfoSchemaCollection', 'ContactInfo',
'<?xml version="1.0" encoding="UTF-8"?>
<xsd:schema targetNamespace="http://schemas.microsoft.com/sqlserver/2004/07/adventure-works/ContactInfo" 
    xmlns="http://schemas.microsoft.com/sqlserver/2004/07/adventure-works/ContactInfo" 
    elementFormDefault="qualified"
    xmlns:xsd="http://www.w3.org/2001/XMLSchema" >
    <!-- the following imports are not needed. They simply provide readability -->

    <xsd:import 
        namespace="http://schemas.microsoft.com/sqlserver/2004/07/adventure-works/ContactRecord" />

    <xsd:import 
        namespace="http://schemas.microsoft.com/sqlserver/2004/07/adventure-works/ContactTypes" />

    <xsd:element name="AdditionalContactInfo" >
        <xsd:complexType mixed="true" >
            <xsd:sequence>
                <xsd:any processContents="strict" 
                    namespace="http://schemas.microsoft.com/sqlserver/2004/07/adventure-works/ContactRecord 
                        http://schemas.microsoft.com/sqlserver/2004/07/adventure-works/ContactTypes"
                        minOccurs="0" maxOccurs="unbounded" />
            </xsd:sequence>
        </xsd:complexType>
    </xsd:element>
</xsd:schema>'),
			('Person', 'AdditionalContactInfoSchemaCollection', 'ContactRecord',
'<?xml version="1.0" encoding="UTF-8"?>
<xsd:schema targetNamespace="http://schemas.microsoft.com/sqlserver/2004/07/adventure-works/ContactRecord"
    elementFormDefault="qualified"
    xmlns="http://schemas.microsoft.com/sqlserver/2004/07/adventure-works/ContactRecord"
    xmlns:xsd="http://www.w3.org/2001/XMLSchema" >

    <xsd:element name="ContactRecord" >
        <xsd:complexType mixed="true" >
            <xsd:choice minOccurs="0" maxOccurs="unbounded" >
                <xsd:any processContents="strict"  
                    namespace="http://schemas.microsoft.com/sqlserver/2004/07/adventure-works/ContactTypes" />
            </xsd:choice>
            <xsd:attribute name="date" type="xsd:date" />
        </xsd:complexType>
    </xsd:element>
</xsd:schema>'),
			('Person', 'AdditionalContactInfoSchemaCollection', 'ContactTypes',
'<?xml version="1.0" encoding="UTF-8"?>
<xsd:schema targetNamespace="http://schemas.microsoft.com/sqlserver/2004/07/adventure-works/ContactTypes"
    xmlns="http://schemas.microsoft.com/sqlserver/2004/07/adventure-works/ContactTypes" 
    elementFormDefault="qualified"
    xmlns:xsd="http://www.w3.org/2001/XMLSchema" >

    <xsd:complexType name="specialInstructionsType" mixed="true">
        <xsd:sequence>
            <xsd:any processContents="strict" 
                namespace = "##targetNamespace"
                minOccurs="0" maxOccurs="unbounded" />
        </xsd:sequence>
    </xsd:complexType>

    <xsd:complexType name="phoneNumberType">
        <xsd:sequence>
            <xsd:element name="number" >
                <xsd:simpleType>
                    <xsd:restriction base="xsd:string">
                        <xsd:pattern value="[0-9\(\)\-]*"/>
                    </xsd:restriction>
                </xsd:simpleType>
            </xsd:element>
            <xsd:element name="SpecialInstructions" minOccurs="0" type="specialInstructionsType" />
        </xsd:sequence>
    </xsd:complexType>

    <xsd:complexType name="eMailType">
        <xsd:sequence>
            <xsd:element name="eMailAddress" type="xsd:string" />
            <xsd:element name="SpecialInstructions" minOccurs="0" type="specialInstructionsType" />
        </xsd:sequence>
    </xsd:complexType>

    <xsd:complexType name="addressType">
        <xsd:sequence>
            <xsd:element name="Street" type="xsd:string" minOccurs="1" maxOccurs="2" />
            <xsd:element name="City" type="xsd:string" minOccurs="1" maxOccurs="1" />
            <xsd:element name="StateProvince" type="xsd:string" minOccurs="1" maxOccurs="1" />
            <xsd:element name="PostalCode" type="xsd:string" minOccurs="0" maxOccurs="1" />
            <xsd:element name="CountryRegion" type="xsd:string" minOccurs="1" maxOccurs="1" />
            <xsd:element name="SpecialInstructions" type="specialInstructionsType" minOccurs="0"/>
        </xsd:sequence>
    </xsd:complexType>

    <xsd:element name="telephoneNumber"            type="phoneNumberType" />
    <xsd:element name="mobile"                     type="phoneNumberType" />
    <xsd:element name="pager"                      type="phoneNumberType" />
    <xsd:element name="facsimileTelephoneNumber"   type="phoneNumberType" />
    <xsd:element name="telexNumber"                type="phoneNumberType" />
    <xsd:element name="internationaliSDNNumber"    type="phoneNumberType" />
    <xsd:element name="eMail"                      type="eMailType" />
    <xsd:element name="homePostalAddress"          type="addressType" />
    <xsd:element name="physicalDeliveryOfficeName" type="addressType" />
    <xsd:element name="registeredAddress"          type="addressType" /> 
</xsd:schema>'),
			('Person', 'IndividualSurveySchemaCollection', 'IndividualSurvey',
'<?xml version="1.0" encoding="UTF-8"?>
<xsd:schema targetNamespace="http://schemas.microsoft.com/sqlserver/2004/07/adventure-works/IndividualSurvey" 
    xmlns="http://schemas.microsoft.com/sqlserver/2004/07/adventure-works/IndividualSurvey"
    elementFormDefault="qualified"
    xmlns:xsd="http://www.w3.org/2001/XMLSchema" >

    <xsd:simpleType name="SalaryType">
        <xsd:restriction base="xsd:string">
            <xsd:enumeration value="0-25000" />
            <xsd:enumeration value="25001-50000" />
            <xsd:enumeration value="50001-75000" />
            <xsd:enumeration value="75001-100000" />
            <xsd:enumeration value="greater than 100000" />
        </xsd:restriction>
    </xsd:simpleType>

    <xsd:simpleType name="MileRangeType">
        <xsd:restriction base="xsd:string">
            <xsd:enumeration value="0-1 Miles" />
            <xsd:enumeration value="1-2 Miles" />
            <xsd:enumeration value="2-5 Miles" />
            <xsd:enumeration value="5-10 Miles" />
            <xsd:enumeration value="10+ Miles" />
        </xsd:restriction>
    </xsd:simpleType>

    <xsd:element name="IndividualSurvey">
        <xsd:complexType>
            <xsd:sequence>
                <xsd:element name="TotalPurchaseYTD" type="xsd:decimal" minOccurs="0" maxOccurs="1" />
                <xsd:element name="DateFirstPurchase" type="xsd:date" minOccurs="0" maxOccurs="1" />
                <xsd:element name="BirthDate" type="xsd:date" minOccurs="0" maxOccurs="1" />
                <xsd:element name="MaritalStatus" type="xsd:string" minOccurs="0" maxOccurs="1" />
                <xsd:element name="YearlyIncome" type="SalaryType" minOccurs="0" maxOccurs="1" />
                <xsd:element name="Gender" type="xsd:string" minOccurs="0" maxOccurs="1" />
                <xsd:element name="TotalChildren" type="xsd:int" minOccurs="0" maxOccurs="1" />
                <xsd:element name="NumberChildrenAtHome" type="xsd:int" minOccurs="0" maxOccurs="1" />
                <xsd:element name="Education" type="xsd:string" minOccurs="0" maxOccurs="1" />
                <xsd:element name="Occupation" type="xsd:string" minOccurs="0" maxOccurs="1" />
                <xsd:element name="HomeOwnerFlag" type="xsd:string" minOccurs="0" maxOccurs="1" />
                <xsd:element name="NumberCarsOwned" type="xsd:int" minOccurs="0" maxOccurs="1" />
                <xsd:element name="Hobby" type="xsd:string" minOccurs="0" maxOccurs="unbounded" />
                <xsd:element name="CommuteDistance" type="MileRangeType" minOccurs="0" maxOccurs="1" />
                <xsd:element name="Comments" type="xsd:string" minOccurs="0" maxOccurs="1" />
            </xsd:sequence>
        </xsd:complexType>
    </xsd:element>
</xsd:schema>'),
			('HumanResources', 'HRResumeSchemaCollection', 'Resume',
'<?xml version="1.0" encoding="UTF-8"?>
<xsd:schema targetNamespace="http://schemas.microsoft.com/sqlserver/2004/07/adventure-works/Resume" 
    xmlns="http://schemas.microsoft.com/sqlserver/2004/07/adventure-works/Resume" 
    xmlns:xsd="http://www.w3.org/2001/XMLSchema" 
    elementFormDefault="qualified" >

    <xsd:element name="Resume" type="ResumeType"/>
    <xsd:element name="Address" type="AddressType"/>
    <xsd:element name="Education" type="EducationType"/>
    <xsd:element name="Employment" type="EmploymentType"/>
    <xsd:element name="Location" type="LocationType"/>
    <xsd:element name="Name" type="NameType"/>
    <xsd:element name="Telephone" type="TelephoneType"/>

    <xsd:complexType name="ResumeType">
        <xsd:sequence>
            <xsd:element ref="Name"/>
            <xsd:element name="Skills" type="xsd:string" minOccurs="0"/>
            <xsd:element ref="Employment" maxOccurs="unbounded"/>
            <xsd:element ref="Education" maxOccurs="unbounded"/>
            <xsd:element ref="Address" maxOccurs="unbounded"/>
            <xsd:element ref="Telephone" minOccurs="0"/>
            <xsd:element name="EMail" type="xsd:string" minOccurs="0"/>
            <xsd:element name="WebSite" type="xsd:string" minOccurs="0"/>
        </xsd:sequence>
    </xsd:complexType>

    <xsd:complexType name="AddressType">
        <xsd:sequence>
            <xsd:element name="Addr.Type" type="xsd:string">
                <xsd:annotation>
                    <xsd:documentation>Home|Work|Permanent</xsd:documentation>
                </xsd:annotation>
            </xsd:element>
            <xsd:element name="Addr.OrgName" type="xsd:string" minOccurs="0"/>
            <xsd:element name="Addr.Street" type="xsd:string" maxOccurs="unbounded"/>
            <xsd:element name="Addr.Location">
                <xsd:complexType>
                    <xsd:sequence>
                        <xsd:element ref="Location"/>
                    </xsd:sequence>
                </xsd:complexType>
            </xsd:element>
            <xsd:element name="Addr.PostalCode" type="xsd:string"/>
            <xsd:element name="Addr.Telephone" minOccurs="0">
                <xsd:complexType>
                    <xsd:sequence>
                        <xsd:element ref="Telephone" maxOccurs="unbounded"/>
                    </xsd:sequence>
                </xsd:complexType>
            </xsd:element>
        </xsd:sequence>
    </xsd:complexType>

    <xsd:complexType name="EducationType">
        <xsd:sequence>
            <xsd:element name="Edu.Level" type="xsd:string">
                <xsd:annotation>
                    <xsd:documentation>High School|Associate|Bachelor|Master|Doctorate</xsd:documentation>
                </xsd:annotation>
            </xsd:element>
            <xsd:element name="Edu.StartDate" type="xsd:date"/>
            <xsd:element name="Edu.EndDate" type="xsd:date"/>
            <xsd:element name="Edu.Degree" type="xsd:string" minOccurs="0"/>
            <xsd:element name="Edu.Major" type="xsd:string" minOccurs="0"/>
            <xsd:element name="Edu.Minor" type="xsd:string" minOccurs="0"/>
            <xsd:element name="Edu.GPA" type="xsd:string" minOccurs="0"/>
            <xsd:element name="Edu.GPAAlternate" type="xsd:decimal" minOccurs="0">
                <xsd:annotation>
                    <xsd:documentation>In case the institution does not follow a GPA system</xsd:documentation>
                </xsd:annotation>
            </xsd:element>
            <xsd:element name="Edu.GPAScale" type="xsd:decimal" minOccurs="0"/>
            <xsd:element name="Edu.School" type="xsd:string" minOccurs="0"/>
            <xsd:element name="Edu.Location" minOccurs="0">
                <xsd:complexType>
                    <xsd:sequence>
                        <xsd:element ref="Location"/>
                    </xsd:sequence>
                </xsd:complexType>
            </xsd:element>
        </xsd:sequence>
    </xsd:complexType>

    <xsd:complexType name="EmploymentType">
        <xsd:sequence>
            <xsd:element name="Emp.StartDate" type="xsd:date" minOccurs="0"/>
            <xsd:element name="Emp.EndDate" type="xsd:date" minOccurs="0"/>
            <xsd:element name="Emp.OrgName" type="xsd:string"/>
            <xsd:element name="Emp.JobTitle" type="xsd:string"/>
            <xsd:element name="Emp.Responsibility" type="xsd:string"/>
            <xsd:element name="Emp.FunctionCategory" type="xsd:string" minOccurs="0"/>
            <xsd:element name="Emp.IndustryCategory" type="xsd:string" minOccurs="0"/>
            <xsd:element name="Emp.Location" minOccurs="0">
                <xsd:complexType>
                    <xsd:sequence>
                        <xsd:element ref="Location"/>
                    </xsd:sequence>
                </xsd:complexType>
            </xsd:element>
        </xsd:sequence>
    </xsd:complexType>

    <xsd:complexType name="LocationType">
        <xsd:sequence>
            <xsd:element name="Loc.CountryRegion" type="xsd:string">
                <xsd:annotation>
                    <xsd:documentation>ISO 3166 Country Code</xsd:documentation>
                </xsd:annotation>
            </xsd:element>
            <xsd:element name="Loc.State" type="xsd:string" minOccurs="0"/>
            <xsd:element name="Loc.City" type="xsd:string" minOccurs="0"/>
        </xsd:sequence>
    </xsd:complexType>

    <xsd:complexType name="NameType">
        <xsd:sequence>
            <xsd:element name="Name.Prefix" type="xsd:string" minOccurs="0"/>
            <xsd:element name="Name.First" type="xsd:string"/>
            <xsd:element name="Name.Middle" type="xsd:string" minOccurs="0"/>
            <xsd:element name="Name.Last" type="xsd:string"/>
            <xsd:element name="Name.Suffix" type="xsd:string" minOccurs="0"/>
        </xsd:sequence>
    </xsd:complexType>

    <xsd:complexType name="TelephoneType">
        <xsd:sequence>
            <xsd:element name="Tel.Type" minOccurs="0">
                <xsd:annotation>
                    <xsd:documentation>Voice|Fax|Pager</xsd:documentation>
                </xsd:annotation>
            </xsd:element>
            <xsd:element name="Tel.IntlCode" type="xsd:int" minOccurs="0"/>
            <xsd:element name="Tel.AreaCode" type="xsd:int" minOccurs="0"/>
            <xsd:element name="Tel.Number" type="xsd:string"/>
            <xsd:element name="Tel.Extension" type="xsd:int" minOccurs="0"/>
        </xsd:sequence>
    </xsd:complexType>
</xsd:schema>'),
			('Production', 'ProductDescriptionSchemaCollection', 'ProductModelWarrAndMain',
'<xsd:schema targetNamespace="http://schemas.microsoft.com/sqlserver/2004/07/adventure-works/ProductModelWarrAndMain"
    xmlns="http://schemas.microsoft.com/sqlserver/2004/07/adventure-works/ProductModelWarrAndMain" 
    elementFormDefault="qualified" 
    xmlns:xsd="http://www.w3.org/2001/XMLSchema" >
  
    <xsd:element name="Warranty"  >
        <xsd:complexType>
            <xsd:sequence>
                <xsd:element name="WarrantyPeriod" type="xsd:string"  />
                <xsd:element name="Description" type="xsd:string"  />
            </xsd:sequence>
        </xsd:complexType>
    </xsd:element>

    <xsd:element name="Maintenance"  >
        <xsd:complexType>
            <xsd:sequence>
                <xsd:element name="NoOfYears" type="xsd:string"  />
                <xsd:element name="Description" type="xsd:string"  />
            </xsd:sequence>
        </xsd:complexType>
    </xsd:element>
</xsd:schema>'),
			('Production', 'ProductDescriptionSchemaCollection', 'ProductModelDescription',
'<?xml version="1.0" encoding="UTF-8"?>
<xs:schema targetNamespace="http://schemas.microsoft.com/sqlserver/2004/07/adventure-works/ProductModelDescription" 
    xmlns="http://schemas.microsoft.com/sqlserver/2004/07/adventure-works/ProductModelDescription" 
    elementFormDefault="qualified" 
    xmlns:mstns="http://tempuri.org/XMLSchema.xsd" 
    xmlns:xs="http://www.w3.org/2001/XMLSchema"
    xmlns:wm="http://schemas.microsoft.com/sqlserver/2004/07/adventure-works/ProductModelWarrAndMain" >

    <xs:import 
        namespace="http://schemas.microsoft.com/sqlserver/2004/07/adventure-works/ProductModelWarrAndMain" />

    <xs:element name="ProductDescription" type="ProductDescription" />
        <xs:complexType name="ProductDescription">
            <xs:annotation>
                <xs:documentation>Product description has a summary blurb, if its manufactured elsewhere it 
                includes a link to the manufacturers site for this component.
                Then it has optional zero or more sequences of features, pictures, categories
                and technical specifications.
                </xs:documentation>
            </xs:annotation>
            <xs:sequence>
                <xs:element name="Summary" type="Summary" minOccurs="0" />
                <xs:element name="Manufacturer" type="Manufacturer" minOccurs="0" />
                <xs:element name="Features" type="Features" minOccurs="0" maxOccurs="unbounded" />
                <xs:element name="Picture" type="Picture" minOccurs="0" maxOccurs="unbounded" />
                <xs:element name="Category" type="Category" minOccurs="0" maxOccurs="unbounded" />
                <xs:element name="Specifications" type="Specifications" minOccurs="0" maxOccurs="unbounded" />
            </xs:sequence>
            <xs:attribute name="ProductModelID" type="xs:string" />
            <xs:attribute name="ProductModelName" type="xs:string" />
        </xs:complexType>
  
        <xs:complexType name="Summary" mixed="true" >
            <xs:sequence>
                <xs:any processContents="skip" namespace="http://www.w3.org/1999/xhtml" minOccurs="0" maxOccurs="unbounded" />
            </xs:sequence>
        </xs:complexType>
        
        <xs:complexType name="Manufacturer">
            <xs:sequence>
                <xs:element name="Name" type="xs:string" minOccurs="0" />
                <xs:element name="CopyrightURL" type="xs:string" minOccurs="0" />
                <xs:element name="Copyright" type="xs:string" minOccurs="0" />
                <xs:element name="ProductURL" type="xs:string" minOccurs="0" />
            </xs:sequence>
        </xs:complexType>
  
        <xs:complexType name="Picture">
            <xs:annotation>
                <xs:documentation>Pictures of the component, some standard sizes are "Large" for zoom in, "Small" for a normal web page and "Thumbnail" for product listing pages.</xs:documentation>
            </xs:annotation>
            <xs:sequence>
                <xs:element name="Name" type="xs:string" minOccurs="0" />
                <xs:element name="Angle" type="xs:string" minOccurs="0" />
                <xs:element name="Size" type="xs:string" minOccurs="0" />
                <xs:element name="ProductPhotoID" type="xs:integer" minOccurs="0" />
            </xs:sequence>
        </xs:complexType>

        <xs:annotation>
            <xs:documentation>Features of the component that are more "sales" oriented.</xs:documentation>
        </xs:annotation>

        <xs:complexType name="Features" mixed="true"  >
            <xs:sequence>
                <xs:element ref="wm:Warranty"  />
                <xs:element ref="wm:Maintenance"  />
                <xs:any processContents="skip"  namespace="##other" minOccurs="0" maxOccurs="unbounded" />
            </xs:sequence>
        </xs:complexType>

        <xs:complexType name="Specifications" mixed="true">
            <xs:annotation>
                <xs:documentation>A single technical aspect of the component.</xs:documentation>
            </xs:annotation>
            <xs:sequence>
                <xs:any processContents="skip" minOccurs="0" maxOccurs="unbounded" />
            </xs:sequence>
        </xs:complexType>

        <xs:complexType name="Category">
            <xs:annotation>
                <xs:documentation>A single categorization element that designates a classification taxonomy and a code within that classification type.  Optional description for default display if needed.</xs:documentation>
            </xs:annotation>
            <xs:sequence>
                <xs:element ref="Taxonomy" />
                <xs:element ref="Code" />
                <xs:element ref="Description" minOccurs="0" />
            </xs:sequence>
        </xs:complexType>

    <xs:element name="Taxonomy" type="xs:string" />
    <xs:element name="Code" type="xs:string" />
    <xs:element name="Description" type="xs:string" />
</xs:schema>'),
			('Production', 'ManuInstructionsSchemaCollection', 'ProductModelManuInstructions',
'<?xml version="1.0" encoding="UTF-8"?>
<xsd:schema targetNamespace="http://schemas.microsoft.com/sqlserver/2004/07/adventure-works/ProductModelManuInstructions" 
    xmlns="http://schemas.microsoft.com/sqlserver/2004/07/adventure-works/ProductModelManuInstructions" 
    elementFormDefault="qualified" attributeFormDefault="unqualified"
    xmlns:xsd="http://www.w3.org/2001/XMLSchema" >

    <xsd:annotation>
        <xsd:documentation>
            SetupHour   is the time it takes to set up the machine.
            MachineHour is the time the machine is busy manufcturing
            LaborHour   is the labor hours in the manu process
            LotSize     is the minimum quanity manufactured. For example,
                    no. of frames cut from the sheet metal
        </xsd:documentation>
    </xsd:annotation>

    <xsd:complexType name="StepType" mixed="true" >
        <xsd:choice  minOccurs="0" maxOccurs="unbounded" > 
            <xsd:element name="tool" type="xsd:string" />
            <xsd:element name="material" type="xsd:string" />
            <xsd:element name="blueprint" type="xsd:string" />
            <xsd:element name="specs" type="xsd:string" />
            <xsd:element name="diag" type="xsd:string" />
        </xsd:choice> 
    </xsd:complexType>

    <xsd:element  name="root">
        <xsd:complexType mixed="true">
            <xsd:sequence>
                <xsd:element name="Location" minOccurs="1" maxOccurs="unbounded">
                    <xsd:complexType mixed="true">
                        <xsd:sequence>
                            <xsd:element name="step" type="StepType" minOccurs="1" maxOccurs="unbounded" />
                        </xsd:sequence>
                        <xsd:attribute name="LocationID" type="xsd:integer" use="required"/>
                        <xsd:attribute name="SetupHours" type="xsd:decimal" use="optional"/>
                        <xsd:attribute name="MachineHours" type="xsd:decimal" use="optional"/>
                        <xsd:attribute name="LaborHours" type="xsd:decimal" use="optional"/>
                        <xsd:attribute name="LotSize" type="xsd:decimal" use="optional"/>
                    </xsd:complexType>
                </xsd:element>
            </xsd:sequence>
        </xsd:complexType>
    </xsd:element>
</xsd:schema>'),
			('Sales', 'StoreSurveySchemaCollection', 'StoreSurvey',
'<?xml version="1.0" encoding="UTF-8"?>
<xsd:schema xmlns:xsd="http://www.w3.org/2001/XMLSchema"
    targetNamespace="http://schemas.microsoft.com/sqlserver/2004/07/adventure-works/StoreSurvey" 
    xmlns="http://schemas.microsoft.com/sqlserver/2004/07/adventure-works/StoreSurvey" 
    elementFormDefault="qualified" attributeFormDefault="unqualified">

    <!-- BM=Bicycle manu BS=bicyle store OS=online store SGS=sporting goods store D=Discount Store -->
    <xsd:simpleType name="BusinessType">
        <xsd:restriction base="xsd:string">
            <xsd:enumeration value="BM" />
            <xsd:enumeration value="BS" />
            <xsd:enumeration value="D" />
            <xsd:enumeration value="OS" />
            <xsd:enumeration value="SGS" />
        </xsd:restriction>
    </xsd:simpleType>

    <!-- BMX=BMX Racing -->
    <xsd:simpleType name="SpecialtyType">
        <xsd:restriction base="xsd:string">
            <xsd:enumeration value="Family" />
            <xsd:enumeration value="Kids" />
            <xsd:enumeration value="BMX" />
            <xsd:enumeration value="Touring" />
            <xsd:enumeration value="Road" />
            <xsd:enumeration value="Mountain" />
            <xsd:enumeration value="All" />
        </xsd:restriction>
    </xsd:simpleType>

    <!-- AW=AdventureWorks only 2= AdvWorks+1 other brand other brand -->
    <xsd:simpleType name="BrandType">
        <xsd:restriction base="xsd:string">
            <xsd:enumeration value="AW" />
            <xsd:enumeration value="2" />
            <xsd:enumeration value="3" />
            <xsd:enumeration value="4+" />
        </xsd:restriction>
    </xsd:simpleType>

    <xsd:simpleType name="InternetType">
        <xsd:restriction base="xsd:string">
            <xsd:enumeration value="56kb" />
            <xsd:enumeration value="ISDN" />
            <xsd:enumeration value="DSL" />
            <xsd:enumeration value="T1" />
            <xsd:enumeration value="T2" />
            <xsd:enumeration value="T3" />
        </xsd:restriction>
    </xsd:simpleType>

    <xsd:element name="StoreSurvey">
        <xsd:complexType>
            <xsd:sequence>
                <xsd:element name="ContactName" type="xsd:string" minOccurs="0" maxOccurs="1" />
                <xsd:element name="JobTitle" type="xsd:string" minOccurs="0" maxOccurs="1" />
                <xsd:element name="AnnualSales" type="xsd:decimal" minOccurs="0" maxOccurs="1" />
                <xsd:element name="AnnualRevenue" type="xsd:decimal" minOccurs="0" maxOccurs="1" />
                <xsd:element name="BankName" type="xsd:string" minOccurs="0" maxOccurs="1" />
                <xsd:element name="BusinessType" type="BusinessType" minOccurs="0" maxOccurs="1" />
                <xsd:element name="YearOpened" type="xsd:gYear" minOccurs="0" maxOccurs="1" />
                <xsd:element name="Specialty" type="SpecialtyType" minOccurs="0" maxOccurs="1" />
                <xsd:element name="SquareFeet" type="xsd:float" minOccurs="0" maxOccurs="1" />
                <xsd:element name="Brands" type="BrandType" minOccurs="0" maxOccurs="1" />
                <xsd:element name="Internet" type="InternetType" minOccurs="0" maxOccurs="1" />
                <xsd:element name="NumberEmployees" type="xsd:int" minOccurs="0" maxOccurs="1" />
                <xsd:element name="Comments" type="xsd:string" minOccurs="0" maxOccurs="1" />
            </xsd:sequence>
        </xsd:complexType>
    </xsd:element>
</xsd:schema>'));

CREATE TEMPORARY TABLE address_temp (
	AddressID int,
	AddressLine1 varchar(60) NOT NULL,
	AddressLine2 varchar(60) NULL,
	City varchar(30) NOT NULL,
	StateProvinceID int NOT NULL,
	PostalCode varchar(15) NOT NULL,
	SpatialLocation text NULL,
	rowguid uuid NOT NULL,
	ModifiedDate timestamp NOT NULL
	);
\COPY address_temp FROM 'Address.csv' CSV HEADER;

INSERT INTO Person.Address (AddressID,AddressLine1,AddressLine2,City,StateProvinceID,PostalCode,SpatialLocation,rowguid,ModifiedDate)
SELECT	AddressID, AddressLine1, AddressLine2, City, StateProvinceID, PostalCode,
		ST_GeographyFromText(SpatialLocation), rowguid, ModifiedDate
FROM	address_temp;

DROP TABLE address_temp;

\COPY Person.AddressType FROM 'AddressType.csv' CSV HEADER;

\COPY dbo.AWBuildVersion FROM 'AWBuildVersion.csv' CSV HEADER;

\COPY Production.BillOfMaterials FROM BillOfMaterials.csv CSV HEADER;

\COPY Person.BusinessEntity FROM BusinessEntity.csv CSV HEADER;

\COPY Person.BusinessEntityAddress FROM BusinessEntityAddress.csv CSV HEADER;

\COPY Person.BusinessEntityContact FROM BusinessEntityContact.csv CSV HEADER;

\COPY Person.ContactType FROM ContactType.csv CSV HEADER;

\COPY Person.CountryRegion FROM CountryRegion.csv CSV HEADER;

\COPY Sales.CountryRegionCurrency FROM CountryRegionCurrency.csv CSV HEADER;

\COPY Sales.CreditCard FROM CreditCard.csv CSV HEADER;

\COPY Production.Culture FROM Culture.csv CSV HEADER;

\COPY Production.Currency FROM Currency.csv CSV HEADER;

\COPY Production.CurrencyRate FROM CurrencyRate.csv CSV HEADER;

\COPY Sales.Customer FROM Customer.csv CSV HEADER;

\COPY HumanResources.Department FROM Department.csv CSV HEADER;

\COPY Production.Document FROM Document.csv CSV HEADER;

\COPY Person.EmailAddress FROM EmailAddress.csv CSV HEADER;

\COPY HumanResources.Employee FROM Employee.csv CSV HEADER;

\COPY HumanResources.EmployeeDepartmentHistory FROM EmployeeDepartmentHistory.csv CSV HEADER;

\COPY HumanResources.EmployeePayHistory FROM EmployeePayHistory.csv CSV HEADER;

\COPY Production.Illustration FROM Illustration.csv USING DELIMITERS '|' CSV HEADER;

\COPY HumanResources.JobCandidate FROM JobCandidate.csv CSV HEADER;

\COPY Production.Location FROM Location.csv CSV HEADER;

\COPY Person.Password FROM Password.csv CSV HEADER;

\COPY Person.Person FROM Person.csv USING DELIMITERS '|' CSV HEADER;

\COPY Sales.PersonCreditCard FROM PersonCreditCard.csv CSV HEADER;

\COPY Person.PersonPhone FROM PersonPhone.csv CSV HEADER;

\COPY Person.PhoneNumberType FROM PhoneNumberType.csv CSV HEADER;

\COPY Production.Product FROM Product.csv CSV HEADER;

\COPY Production.ProductCategory FROM ProductCategory.csv CSV HEADER;

\COPY Production.ProductCostHistory FROM ProductCostHistory.csv CSV HEADER;

\COPY Production.ProductDescription FROM ProductDescription.csv CSV HEADER;

\COPY Production.ProductDocument FROM ProductDocument.csv CSV HEADER;

\COPY Production.ProductInventory FROM ProductInventory.csv CSV HEADER;

\COPY Production.ProductListPriceHistory FROM ProductListPriceHistory.csv CSV HEADER;

\COPY Production.ProductModel FROM ProductModel.csv USING DELIMITERS '|' CSV HEADER;

\COPY Production.ProductModelIllustration FROM ProductModelIllustration.csv CSV HEADER;

\COPY Production.ProductModelProductDescriptionCulture FROM ProductModelProductDescriptionCulture.csv CSV HEADER;

\COPY Production.ProductPhoto FROM ProductPhoto.csv USING DELIMITERS '|' CSV HEADER;

\COPY Production.ProductProductPhoto FROM ProductProductPhoto.csv CSV HEADER;

\COPY Production.ProductReview FROM ProductReview.csv CSV HEADER;

\COPY Production.ProductSubcategory FROM ProductSubcategory.csv CSV HEADER;

\COPY Purchasing.ProductVendor FROM ProductVendor.csv CSV HEADER;

\COPY Purchasing.PurchaseOrderDetail FROM PurchaseOrderDetail.csv CSV HEADER;

\COPY Purchasing.PurchaseOrderHeader FROM PurchaseOrderHeader.csv CSV HEADER;

\COPY Sales.SalesOrderDetail FROM SalesOrderDetail.csv CSV HEADER;

\COPY Sales.SalesOrderHeader FROM SalesOrderHeader.csv CSV HEADER;

\COPY Sales.SalesOrderHeaderSalesReason FROM SalesOrderHeaderSalesReason.csv CSV HEADER;

\COPY Sales.SalesPerson FROM SalesPerson.csv CSV HEADER;

\COPY Sales.SalesPersonQuotaHistory FROM SalesPersonQuotaHistory.csv CSV HEADER;

\COPY Sales.SalesReason FROM SalesReason.csv CSV HEADER;

\COPY Sales.SalesTaxRate FROM SalesTaxRate.csv CSV HEADER;

\COPY Sales.SalesTerritory FROM SalesTerritory.csv CSV HEADER;

\COPY Sales.SalesTerritoryHistory FROM SalesTerritoryHistory.csv CSV HEADER;

\COPY Production.ScrapReason FROM ScrapReason.csv CSV HEADER;

\COPY HumanResources.Shift FROM Shift.csv CSV HEADER;

\COPY Purchasing.ShipMethod FROM ShipMethod.csv CSV HEADER;

\COPY Sales.ShoppingCartItem FROM ShoppingCartItem.csv CSV HEADER;

\COPY Sales.SpecialOffer FROM SpecialOffer.csv CSV HEADER;

\COPY Sales.SpecialOfferProduct FROM SpecialOfferProduct.csv CSV HEADER;

\COPY Person.StateProvince FROM StateProvince.csv CSV HEADER;

\COPY Sales.Store FROM Store.csv USING DELIMITERS '|' CSV HEADER;

\COPY Production.TransactionHistory FROM TransactionHistory.csv CSV HEADER;

\COPY Production.TransactionHistoryArchive FROM TransactionHistoryArchive.csv CSV HEADER;

\COPY Production.UnitMeasure FROM UnitMeasure.csv CSV HEADER;

\COPY Purchasing.Vendor FROM Vendor.csv CSV HEADER;

\COPY Production.WorkOrder FROM WorkOrder.csv CSV HEADER;

\COPY Production.WorkOrderRouting FROM WorkOrderRouting.csv CSV HEADER;


-- ******************************************************
-- Add Primary Keys
-- ******************************************************
ALTER TABLE Person.Address ADD
	CONSTRAINT PK_Address_AddressID
		PRIMARY KEY (AddressID);

ALTER TABLE Person.AddressType ADD
	CONSTRAINT PK_AddressType_AddressTypeID
		PRIMARY KEY (AddressTypeID);

ALTER TABLE dbo.AWBuildVersion ADD
	CONSTRAINT PK_AWBuildVersion_SystemInformationID
		PRIMARY KEY (SystemInformationID);

ALTER TABLE Production.BillOfMaterials ADD
	CONSTRAINT PK_BillOfMaterials_BillOfMaterialsID
		PRIMARY KEY (BillOfMaterialsID);

ALTER TABLE Person.BusinessEntity ADD
	CONSTRAINT PK_BusinessEntity_BusinessEntityID
		PRIMARY KEY (BusinessEntityID);

ALTER TABLE Person.BusinessEntityAddress ADD
	CONSTRAINT PK_BusinessEntityAddress_BusinessEntityID_AddressID_AddressTypeID
		PRIMARY KEY (BusinessEntityID,AddressID,AddressTypeID);

ALTER TABLE Person.BusinessEntityContact ADD
	CONSTRAINT PK_BusinessEntityContact_BusinessEntityID_PersonID_ContactTypeID
		PRIMARY KEY (BusinessEntityID, PersonID, ContactTypeID);

ALTER TABLE Person.ContactType ADD
	CONSTRAINT PK_ContactType_ContactTypeID
		PRIMARY KEY (ContactTypeID);

ALTER TABLE Sales.CountryRegionCurrency ADD
	CONSTRAINT PK_CountryRegionCurrency_CountryRegionCode_CurrencyCode
		PRIMARY KEY (CountryRegionCode,CurrencyCode);

ALTER TABLE Person.CountryRegion ADD
	CONSTRAINT PK_CountryRegion_CountryRegionCode
		PRIMARY KEY (CountryRegionCode);

ALTER TABLE Sales.CreditCard ADD
	CONSTRAINT PK_CreditCard_CreditCardID
		PRIMARY KEY (CreditCardID);

ALTER TABLE Production.Culture ADD
	CONSTRAINT PK_Culture_CultureID
		PRIMARY KEY (CultureID);

ALTER TABLE Sales.Currency ADD
	CONSTRAINT PK_Currency_CurrencyCode
		PRIMARY KEY (CurrencyCode);

ALTER TABLE Sales.CurrencyRate ADD
	CONSTRAINT PK_CurrencyRate_CurrencyRateID
		PRIMARY KEY (CurrencyRateID);

ALTER TABLE Sales.Customer ADD
	CONSTRAINT PK_Customer_CustomerID
		PRIMARY KEY (CustomerID);

ALTER TABLE Sales.DatabaseLog ADD
	CONSTRAINT PK_DatabaseLog_DatabaseLogID
		PRIMARY KEY (DatabaseLogID);

ALTER TABLE HumanResources.Department ADD
	CONSTRAINT PK_Department_DepartmentID
		PRIMARY KEY (DepartmentID);

ALTER TABLE Production.Document ADD
	CONSTRAINT PK_Document_DocumentNode
		PRIMARY KEY (DocumentNode);

ALTER TABLE Person.EmailAddress ADD
	CONSTRAINT PK_EmailAddress_BusinessEntityID_EmailAddressID
		PRIMARY KEY (BusinessEntityID,EmailAddressID);

ALTER TABLE HumanResources.Employee ADD
	CONSTRAINT PK_Employee_BusinessEntityID
		PRIMARY KEY (BusinessEntityID);

ALTER TABLE HumanResources.EmployeeDepartmentHistory ADD
	CONSTRAINT PK_EmployeeDepartmentHistory_BusinessEntityID_StartDate_DepartmentID
		PRIMARY KEY (BusinessEntityID,StartDate,DepartmentID,ShiftID);

ALTER TABLE HumanResources.EmployeePayHistory ADD
	CONSTRAINT PK_EmployeePayHistory_BusinessEntityID_RateChangeDate
		PRIMARY KEY (BusinessEntityID,RateChangeDate);

ALTER TABLE Production.Illustration ADD
	CONSTRAINT PK_Illustration_IllustrationID
		PRIMARY KEY (IllustrationID);

ALTER TABLE HumanResources.JobCandidate ADD
	CONSTRAINT PK_JobCandidate_JobCandidateID
		PRIMARY KEY (JobCandidateID);

ALTER TABLE Production.Location ADD
	CONSTRAINT PK_Location_LocationID
		PRIMARY KEY (LocationID);

ALTER TABLE Person.Password ADD
	CONSTRAINT PK_Password_BusinessEntityID
		PRIMARY KEY (BusinessEntityID);

ALTER TABLE Person.Person ADD
	CONSTRAINT PK_Person_BusinessEntityID
		PRIMARY KEY (BusinessEntityID);

ALTER TABLE Sales.PersonCreditCard ADD
	CONSTRAINT PK_PersonCreditCard_BusinessEntityID_CreditCardID
		PRIMARY KEY (BusinessEntityID,CreditCardID);

ALTER TABLE Person.PersonPhone ADD
	CONSTRAINT PK_PersonPhone_BusinessEntityID_PhoneNumber_PhoneNumberTypeID
		PRIMARY KEY (BusinessEntityID,PhoneNumber,PhoneNumberTypeID);

ALTER TABLE Person.PhoneNumberType ADD
	CONSTRAINT PK_PhoneNumberType_PhoneNumberTypeID
		PRIMARY KEY (PhoneNumberTypeID);

ALTER TABLE Production.Product ADD
	CONSTRAINT PK_Product_ProductID
		PRIMARY KEY (ProductID);

ALTER TABLE Production.ProductCategory ADD
	CONSTRAINT PK_ProductCategory_ProductCategoryID
		PRIMARY KEY (ProductCategoryID);

ALTER TABLE Production.ProductCostHistory ADD
	CONSTRAINT PK_ProductCostHistory_ProductID_StartDate
		PRIMARY KEY (ProductID,StartDate);

ALTER TABLE Production.ProductDescription ADD
	CONSTRAINT PK_ProductDescription_ProductDescriptionID
		PRIMARY KEY (ProductDescriptionID;

ALTER TABLE Production.ProductDocument ADD
	CONSTRAINT PK_ProductDocument_ProductID_DocumentNode
		PRIMARY KEY (ProductID,DocumentNode);

ALTER TABLE Production.ProductInventory ADD
	CONSTRAINT PK_ProductInventory_ProductID_LocationID
		PRIMARY KEY (ProductID,LocationID);

ALTER TABLE Production.ProductListPriceHistory ADD
	CONSTRAINT PK_ProductListPriceHistory_ProductID_StartDate
		PRIMARY KEY (ProductID,StartDate);

ALTER TABLE Production.ProductModel ADD
	CONSTRAINT PK_ProductModel_ProductModelID
		PRIMARY KEY (ProductModelID);

ALTER TABLE Production.ProductModelIllustration ADD
	CONSTRAINT PK_ProductModelIllustration_ProductModelID_IllustrationID
		PRIMARY KEY (ProductModelID,IllustrationID);

ALTER TABLE Production.ProductModelProductDescriptionCulture ADD
	CONSTRAINT PK_ProductModelProductDescriptionCulture_ProductModelID_ProductDescriptionID_CultureID
		PRIMARY KEY (ProductModelID,ProductDescriptionID,CultureID);

ALTER TABLE Production.ProductPhoto ADD
	CONSTRAINT PK_ProductPhoto_ProductPhotoID
		PRIMARY KEY (ProductPhotoID);

ALTER TABLE Production.ProductProductPhoto ADD
	CONSTRAINT PK_ProductProductPhoto_ProductID_ProductPhotoID
		PRIMARY KEY (ProductID,ProductPhotoID);

ALTER TABLE Production.ProductReview ADD
	CONSTRAINT PK_ProductReview_ProductReviewID
		PRIMARY KEY (ProductReviewID);

ALTER TABLE Production.ProductSubcategory ADD
	CONSTRAINT PK_ProductSubcategory_ProductSubcategoryID
		PRIMARY KEY (ProductSubcategoryID);

ALTER TABLE Purchasing.ProductVendor ADD
	CONSTRAINT PK_ProductVendor_ProductID_BusinessEntityID
		PRIMARY KEY (ProductID,BusinessEntityID);

ALTER TABLE Purchasing.PurchaseOrderDetail ADD
	CONSTRAINT PK_PurchaseOrderDetail_PurchaseOrderID_PurchaseOrderDetailID
		PRIMARY KEY (PurchaseOrderID,PurchaseOrderDetailID);

ALTER TABLE Purchasing.PurchaseOrderHeader ADD
	CONSTRAINT PK_PurchaseOrderHeader_PurchaseOrderID
		PRIMARY KEY (PurchaseOrderID);

ALTER TABLE Sales.SalesOrderDetail ADD
	CONSTRAINT PK_SalesOrderDetail_SalesOrderID_SalesOrderDetailID
		PRIMARY KEY (SalesOrderID,SalesOrderDetailID);

ALTER TABLE Sales.SalesOrderHeader ADD
	CONSTRAINT PK_SalesOrderHeader_SalesOrderID
		PRIMARY KEY (SalesOrderID);

ALTER TABLE Sales.SalesOrderHeaderSalesReason ADD
	CONSTRAINT PK_SalesOrderHeaderSalesReason_SalesOrderID_SalesReasonID
		PRIMARY KEY (SalesOrderID,SalesReasonID);

ALTER TABLE Sales.SalesPerson ADD
	CONSTRAINT PK_SalesPerson_BusinessEntityID
		PRIMARY KEY (BusinessEntityID);

ALTER TABLE Sales.SalesPersonQuotaHistory ADD
	CONSTRAINT PK_SalesPersonQuotaHistory_BusinessEntityID_QuotaDate
		PRIMARY KEY (BusinessEntityID,QuotaDate);

ALTER TABLE Sales.SalesReason ADD
	CONSTRAINT PK_SalesReason_SalesReasonID
		PRIMARY KEY (SalesReasonID);

ALTER TABLE Sales.SalesTaxRate ADD
	CONSTRAINT PK_SalesTaxRate_SalesTaxRateID
		PRIMARY KEY (SalesTaxRateID);

ALTER TABLE Sales.SalesTerritory ADD
	CONSTRAINT PK_SalesTerritory_TerritoryID
		PRIMARY KEY (TerritoryID);

ALTER TABLE Sales.SalesTerritoryHistory ADD
	CONSTRAINT PK_SalesTerritoryHistory_BusinessEntityID_StartDate_TerritoryID
		PRIMARY KEY (BusinessEntityID,StartDate,TerritoryID);

ALTER TABLE Production.ScrapReason ADD
	CONSTRAINT PK_ScrapReason_ScrapReasonID
		PRIMARY KEY (ScrapReasonID);

ALTER TABLE HumanResources.Shift ADD
	CONSTRAINT PK_Shift_ShiftID
		PRIMARY KEY (ShiftID);

ALTER TABLE Purchasing.ShipMethod ADD
	CONSTRAINT PK_ShipMethod_ShipMethodID
		PRIMARY KEY (ShipMethodID);

ALTER TABLE Sales.ShoppingCartItem ADD
	CONSTRAINT PK_ShoppingCartItem_ShoppingCartItemID
		PRIMARY KEY (ShoppingCartItemID);

ALTER TABLE Sales.SpecialOffer ADD
	CONSTRAINT PK_SpecialOffer_SpecialOfferID
		PRIMARY KEY (SpecialOfferID);

ALTER TABLE Sales.SpecialOfferProduct ADD
	CONSTRAINT PK_SpecialOfferProduct_SpecialOfferID_ProductID
		PRIMARY KEY (SpecialOfferID,ProductID);

ALTER TABLE Person.StateProvince ADD
	CONSTRAINT PK_StateProvince_StateProvinceID
		PRIMARY KEY (StateProvinceID);

ALTER TABLE Sales.Store ADD
	CONSTRAINT PK_Store_BusinessEntityID
		PRIMARY KEY (BusinessEntityID);

ALTER TABLE Production.TransactionHistory ADD
	CONSTRAINT PK_TransactionHistory_TransactionID
		PRIMARY KEY (TransactionID);

ALTER TABLE Production.TransactionHistoryArchive ADD
	CONSTRAINT PK_TransactionHistoryArchive_TransactionID
		PRIMARY KEY (TransactionID);

ALTER TABLE Production.UnitMeasure ADD
	CONSTRAINT PK_UnitMeasure_UnitMeasureCode
		PRIMARY KEY (UnitMeasureCode);

ALTER TABLE Purchasing.Vendor ADD
	CONSTRAINT PK_Vendor_BusinessEntityID
		PRIMARY KEY (BusinessEntityID);

ALTER TABLE Production.WorkOrder ADD
	CONSTRAINT PK_WorkOrder_WorkOrderID
		PRIMARY KEY (WorkOrderID);

ALTER TABLE Production.WorkOrderRouting ADD
	CONSTRAINT PK_WorkOrderRouting_WorkOrderID_ProductID_OperationSequence
		PRIMARY KEY (WorkOrderID,ProductID,OperationSequence);


-- ******************************************************
-- Add Indexes
-- ******************************************************
CREATE UNIQUE INDEX AK_Address_rowguid ON Person.Address(rowguid);
CREATE INDEX IX_Address_AddressLine1_AddressLine2_City_StateProvinceID_PostalCode ON Person.Address(AddressLine1,AddressLine2,City,StateProvinceID,PostalCode);
CREATE INDEX IX_Address_StateProvinceID ON Person.Address(StateProvinceID);

CREATE UNIQUE INDEX AK_AddressType_rowguid ON Person.AddressType(rowguid);
CREATE UNIQUE INDEX AK_AddressType_Name ON Person.AddressType(Name);

CREATE INDEX IX_BillOfMaterials_UnitMeasureCode ON Production.BillOfMaterials(UnitMeasureCode);
CREATE UNIQUE INDEX AK_BillOfMaterials_ProductAssemblyID_ComponentID_StartDate ON Production.BillOfMaterials(ProductAssemblyID, ComponentID, StartDate);

CREATE UNIQUE INDEX AK_BusinessEntity_rowguid ON Person.BusinessEntity(rowguid);

CREATE UNIQUE INDEX AK_BusinessEntityAddress_rowguid ON Person.BusinessEntityAddress(rowguid);
CREATE INDEX IX_BusinessEntityAddress_AddressID ON Person.BusinessEntityAddress(AddressID);
CREATE INDEX IX_BusinessEntityAddress_AddressTypeID ON Person.BusinessEntityAddress(AddressTypeID);

CREATE UNIQUE INDEX AK_BusinessEntityContact_rowguid ON Person.BusinessEntityContact(rowguid);
CREATE INDEX IX_BusinessEntityContact_PersonID ON Person.BusinessEntityContact(PersonID);
CREATE INDEX IX_BusinessEntityContact_ContactTypeID ON Person.BusinessEntityContact(ContactTypeID);

CREATE UNIQUE INDEX AK_ContactType_Name ON Person.ContactType(Name);

CREATE INDEX IX_CountryRegionCurrency_CurrencyCode ON Sales.CountryRegionCurrency(CurrencyCode);

CREATE UNIQUE INDEX AK_CountryRegion_Name ON Person.CountryRegion(Name);

CREATE UNIQUE INDEX AK_CreditCard_CardNumber ON Sales.CreditCard(CardNumber);

CREATE UNIQUE INDEX AK_Culture_Name ON Production.Culture(Name);

CREATE UNIQUE INDEX AK_Currency_Name ON Sales.Currency(Name);

CREATE UNIQUE INDEX AK_CurrencyRate_CurrencyRateDate_FromCurrencyCode_ToCurrencyCode ON Sales.CurrencyRate(CurrencyRateDate, FromCurrencyCode, ToCurrencyCode);

CREATE UNIQUE INDEX AK_Customer_rowguid ON Sales.Customer(rowguid);
CREATE UNIQUE INDEX AK_Customer_AccountNumber ON Sales.Customer(AccountNumber);
CREATE INDEX IX_Customer_TerritoryID ON Sales.Customer(TerritoryID);

CREATE UNIQUE INDEX AK_Department_Name ON HumanResources.Department(Name);

CREATE UNIQUE INDEX AK_Document_DocumentLevel_DocumentNode ON Production.Document (DocumentLevel, DocumentNode);
CREATE UNIQUE INDEX AK_Document_rowguid ON Production.Document(rowguid);
CREATE INDEX IX_Document_FileName_Revision ON Production.Document(FileName, Revision);

CREATE INDEX IX_EmailAddress_EmailAddress ON Person.EmailAddress(EmailAddress);

CREATE INDEX IX_Employee_OrganizationNode ON HumanResources.Employee (OrganizationNode);
CREATE INDEX IX_Employee_OrganizationLevel_OrganizationNode ON HumanResources.Employee (OrganizationLevel, OrganizationNode);
CREATE UNIQUE INDEX AK_Employee_LoginID ON HumanResources.Employee(LoginID);
CREATE UNIQUE INDEX AK_Employee_NationalIDNumber ON HumanResources.Employee(NationalIDNumber);
CREATE UNIQUE INDEX AK_Employee_rowguid ON HumanResources.Employee(rowguid);

CREATE INDEX IX_EmployeeDepartmentHistory_DepartmentID ON HumanResources.EmployeeDepartmentHistory(DepartmentID);
CREATE INDEX IX_EmployeeDepartmentHistory_ShiftID ON HumanResources.EmployeeDepartmentHistory(ShiftID);

CREATE INDEX IX_JobCandidate_BusinessEntityID ON HumanResources.JobCandidate(BusinessEntityID);

CREATE UNIQUE INDEX AK_Location_Name ON Production.Location(Name);

CREATE INDEX IX_Person_LastName_FirstName_MiddleName ON Person.Person (LastName, FirstName, MiddleName);
CREATE UNIQUE INDEX AK_Person_rowguid ON Person.Person(rowguid);

CREATE INDEX IX_PersonPhone_PhoneNumber on Person.PersonPhone (PhoneNumber);

CREATE UNIQUE INDEX AK_Product_ProductNumber ON Production.Product(ProductNumber);
CREATE UNIQUE INDEX AK_Product_Name ON Production.Product(Name);
CREATE UNIQUE INDEX AK_Product_rowguid ON Production.Product(rowguid);

CREATE UNIQUE INDEX AK_ProductCategory_Name ON Production.ProductCategory(Name);
CREATE UNIQUE INDEX AK_ProductCategory_rowguid ON Production.ProductCategory(rowguid);

CREATE UNIQUE INDEX AK_ProductDescription_rowguid ON Production.ProductDescription(rowguid);

CREATE UNIQUE INDEX AK_ProductModel_Name ON Production.ProductModel(Name);
CREATE UNIQUE INDEX AK_ProductModel_rowguid ON Production.ProductModel(rowguid);

CREATE NONCLUSTERED INDEX IX_ProductReview_ProductID_Name ON Production.ProductReview(ProductID, ReviewerName) INCLUDE (Comments);

CREATE UNIQUE INDEX AK_ProductSubcategory_Name ON Production.ProductSubcategory(Name);
CREATE UNIQUE INDEX AK_ProductSubcategory_rowguid ON Production.ProductSubcategory(rowguid);

CREATE INDEX IX_ProductVendor_UnitMeasureCode ON Purchasing.ProductVendor(UnitMeasureCode);
CREATE INDEX IX_ProductVendor_BusinessEntityID ON Purchasing.ProductVendor(BusinessEntityID);

CREATE INDEX IX_PurchaseOrderDetail_ProductID ON Purchasing.PurchaseOrderDetail(ProductID);

CREATE INDEX IX_PurchaseOrderHeader_VendorID ON Purchasing.PurchaseOrderHeader(VendorID);
CREATE INDEX IX_PurchaseOrderHeader_EmployeeID ON Purchasing.PurchaseOrderHeader(EmployeeID);

CREATE UNIQUE INDEX AK_SalesOrderDetail_rowguid ON Sales.SalesOrderDetail(rowguid);
CREATE INDEX IX_SalesOrderDetail_ProductID ON Sales.SalesOrderDetail(ProductID);

CREATE UNIQUE INDEX AK_SalesOrderHeader_rowguid ON Sales.SalesOrderHeader(rowguid);
CREATE UNIQUE INDEX AK_SalesOrderHeader_SalesOrderNumber ON Sales.SalesOrderHeader(SalesOrderNumber);
CREATE INDEX IX_SalesOrderHeader_CustomerID ON Sales.SalesOrderHeader(CustomerID);
CREATE INDEX IX_SalesOrderHeader_SalesPersonID ON Sales.SalesOrderHeader(SalesPersonID);

CREATE UNIQUE INDEX AK_SalesPerson_rowguid ON Sales.SalesPerson(rowguid);

CREATE UNIQUE INDEX AK_SalesPersonQuotaHistory_rowguid ON Sales.SalesPersonQuotaHistory(rowguid);

CREATE UNIQUE INDEX AK_SalesTaxRate_StateProvinceID_TaxType ON Sales.SalesTaxRate(StateProvinceID, TaxType);
CREATE UNIQUE INDEX AK_SalesTaxRate_rowguid ON Sales.SalesTaxRate(rowguid);

CREATE UNIQUE INDEX AK_SalesTerritory_Name ON Sales.SalesTerritory(Name);
CREATE UNIQUE INDEX AK_SalesTerritory_rowguid ON Sales.SalesTerritory(rowguid);

CREATE UNIQUE INDEX AK_SalesTerritoryHistory_rowguid ON Sales.SalesTerritoryHistory(rowguid);

CREATE UNIQUE INDEX AK_ScrapReason_Name ON Production.ScrapReason(Name);

CREATE UNIQUE INDEX AK_Shift_Name ON HumanResources.Shift(Name);
CREATE UNIQUE INDEX AK_Shift_StartTime_EndTime ON HumanResources.Shift(StartTime, EndTime);

CREATE UNIQUE INDEX AK_ShipMethod_Name ON Purchasing.ShipMethod(Name);
CREATE UNIQUE INDEX AK_ShipMethod_rowguid ON Purchasing.ShipMethod(rowguid);

CREATE INDEX IX_ShoppingCartItem_ShoppingCartID_ProductID ON Sales.ShoppingCartItem(ShoppingCartID, ProductID);

CREATE UNIQUE INDEX AK_SpecialOffer_rowguid ON Sales.SpecialOffer(rowguid);

CREATE UNIQUE INDEX AK_SpecialOfferProduct_rowguid ON Sales.SpecialOfferProduct(rowguid);
CREATE INDEX IX_SpecialOfferProduct_ProductID ON Sales.SpecialOfferProduct(ProductID);

CREATE UNIQUE INDEX AK_StateProvince_Name ON Person.StateProvince(Name);
CREATE UNIQUE INDEX AK_StateProvince_StateProvinceCode_CountryRegionCode ON Person.StateProvince(StateProvinceCode, CountryRegionCode);
CREATE UNIQUE INDEX AK_StateProvince_rowguid ON Person.StateProvince(rowguid);

CREATE UNIQUE INDEX AK_Store_rowguid ON Sales.Store(rowguid);
CREATE INDEX IX_Store_SalesPersonID ON Sales.Store(SalesPersonID);

CREATE INDEX IX_TransactionHistory_ProductID ON Production.TransactionHistory(ProductID);
CREATE INDEX IX_TransactionHistory_ReferenceOrderID_ReferenceOrderLineID ON Production.TransactionHistory(ReferenceOrderID, ReferenceOrderLineID);

CREATE INDEX IX_TransactionHistoryArchive_ProductID ON Production.TransactionHistoryArchive(ProductID);
CREATE INDEX IX_TransactionHistoryArchive_ReferenceOrderID_ReferenceOrderLineID ON Production.TransactionHistoryArchive(ReferenceOrderID, ReferenceOrderLineID);

CREATE UNIQUE INDEX AK_UnitMeasure_Name ON Production.UnitMeasure(Name);

CREATE UNIQUE INDEX AK_Vendor_AccountNumber ON Purchasing.Vendor(AccountNumber);

CREATE INDEX IX_WorkOrder_ScrapReasonID ON Production.WorkOrder(ScrapReasonID);
CREATE INDEX IX_WorkOrder_ProductID ON Production.WorkOrder(ProductID);

CREATE INDEX IX_WorkOrderRouting_ProductID ON Production.WorkOrderRouting(ProductID);


-- ****************************************
-- Create Foreign key constraints
-- ****************************************
ALTER TABLE Person.Address ADD
	CONSTRAINT FK_Address_StateProvince_StateProvinceID FOREIGN KEY (StateProvinceID) REFERENCES Person.StateProvince(StateProvinceID);

ALTER TABLE Production.BillOfMaterials ADD
	CONSTRAINT FK_BillOfMaterials_Product_ProductAssemblyID FOREIGN KEY (ProductAssemblyID) REFERENCES Production.Product(ProductID),
	CONSTRAINT FK_BillOfMaterials_Product_ComponentID FOREIGN KEY (ComponentID) REFERENCES Production.Product(ProductID),
	CONSTRAINT FK_BillOfMaterials_UnitMeasure_UnitMeasureCode FOREIGN KEY (UnitMeasureCode) REFERENCES Production.UnitMeasure(UnitMeasureCode);

ALTER TABLE Person.BusinessEntityAddress ADD 
	CONSTRAINT FK_BusinessEntityAddress_Address_AddressID FOREIGN KEY (AddressID) REFERENCES Person.Address(AddressID),
	CONSTRAINT FK_BusinessEntityAddress_AddressType_AddressTypeID FOREIGN KEY (AddressTypeID) REFERENCES Person.AddressType(AddressTypeID),
	CONSTRAINT FK_BusinessEntityAddress_BusinessEntity_BusinessEntityID FOREIGN KEY (BusinessEntityID) REFERENCES Person.BusinessEntity(BusinessEntityID);

ALTER TABLE Person.BusinessEntityContact ADD
	CONSTRAINT FK_BusinessEntityContact_Person_PersonID FOREIGN KEY (PersonID) REFERENCES Person.Person(BusinessEntityID),
	CONSTRAINT FK_BusinessEntityContact_ContactType_ContactTypeID FOREIGN KEY (ContactTypeID) REFERENCES Person.ContactType(ContactTypeID),
	CONSTRAINT FK_BusinessEntityContact_BusinessEntity_BusinessEntityID FOREIGN KEY (BusinessEntityID) REFERENCES Person.BusinessEntity(BusinessEntityID);

ALTER TABLE Sales.CountryRegionCurrency ADD
	CONSTRAINT FK_CountryRegionCurrency_CountryRegion_CountryRegionCode FOREIGN KEY (CountryRegionCode) REFERENCES Person.CountryRegion(CountryRegionCode),
	CONSTRAINT FK_CountryRegionCurrency_Currency_CurrencyCode FOREIGN KEY (CurrencyCode) REFERENCES Sales.Currency(CurrencyCode);

ALTER TABLE Sales.CurrencyRate ADD
	CONSTRAINT FK_CurrencyRate_Currency_FromCurrencyCode FOREIGN KEY (FromCurrencyCode) REFERENCES Sales.Currency(CurrencyCode),
	CONSTRAINT FK_CurrencyRate_Currency_ToCurrencyCode FOREIGN KEY (ToCurrencyCode) REFERENCES Sales.Currency(CurrencyCode);

ALTER TABLE Sales.Customer ADD
	CONSTRAINT FK_Customer_Person_PersonID FOREIGN KEY (PersonID) REFERENCES Person.Person(BusinessEntityID),
	CONSTRAINT FK_Customer_Store_StoreID FOREIGN KEY (StoreID) REFERENCES Sales.Store(BusinessEntityID),
	CONSTRAINT FK_Customer_SalesTerritory_TerritoryID FOREIGN KEY (TerritoryID) REFERENCES Sales.SalesTerritory(TerritoryID);

ALTER TABLE Production.Document ADD
	CONSTRAINT FK_Document_Employee_Owner FOREIGN KEY	(Owner) REFERENCES HumanResources.Employee(BusinessEntityID);

ALTER TABLE [Person].[EmailAddress] ADD
	CONSTRAINT [FK_EmailAddress_Person_BusinessEntityID] FOREIGN KEY (BusinessEntityID) REFERENCES Person.Person(BusinessEntityID);

ALTER TABLE HumanResources.Employee ADD
	CONSTRAINT FK_Employee_Person_BusinessEntityID FOREIGN KEY (BusinessEntityID) REFERENCES Person.Person(BusinessEntityID);

ALTER TABLE HumanResources.EmployeeDepartmentHistory ADD
	CONSTRAINT FK_EmployeeDepartmentHistory_Department_DepartmentID FOREIGN KEY (DepartmentID) REFERENCES HumanResources.Department(DepartmentID),
	CONSTRAINT FK_EmployeeDepartmentHistory_Employee_BusinessEntityID FOREIGN KEY (BusinessEntityID) REFERENCES HumanResources.Employee(BusinessEntityID),
	CONSTRAINT FK_EmployeeDepartmentHistory_Shift_ShiftID FOREIGN KEY (ShiftID) REFERENCES HumanResources.Shift(ShiftID);

ALTER TABLE HumanResources.EmployeePayHistory ADD
	CONSTRAINT FK_EmployeePayHistory_Employee_BusinessEntityID FOREIGN KEY (BusinessEntityID) REFERENCES HumanResources.Employee(BusinessEntityID);

ALTER TABLE HumanResources.JobCandidate ADD
	CONSTRAINT FK_JobCandidate_Employee_BusinessEntityID FOREIGN KEY (BusinessEntityID) REFERENCES HumanResources.Employee(BusinessEntityID);

ALTER TABLE Person.Password ADD
	CONSTRAINT FK_Password_Person_BusinessEntityID FOREIGN KEY (BusinessEntityID) REFERENCES Person.Person(BusinessEntityID);

ALTER TABLE Person.Person ADD
	CONSTRAINT FK_Person_BusinessEntity_BusinessEntityID FOREIGN KEY (BusinessEntityID) REFERENCES Person.BusinessEntity(BusinessEntityID);

ALTER TABLE Sales.PersonCreditCard ADD
	CONSTRAINT FK_PersonCreditCard_Person_BusinessEntityID FOREIGN KEY (BusinessEntityID) REFERENCES Person.Person(BusinessEntityID),
	CONSTRAINT FK_PersonCreditCard_CreditCard_CreditCardID FOREIGN KEY (CreditCardID) REFERENCES Sales.CreditCard(CreditCardID);

ALTER TABLE Person.PersonPhone ADD
	CONSTRAINT FK_PersonPhone_Person_BusinessEntityID FOREIGN KEY (BusinessEntityID) REFERENCES Person.Person(BusinessEntityID),
	CONSTRAINT FK_PersonPhone_PhoneNumberType_PhoneNumberTypeID FOREIGN KEY (PhoneNumberTypeID) REFERENCES Person.PhoneNumberType(PhoneNumberTypeID);

ALTER TABLE Production.Product ADD
	CONSTRAINT FK_Product_UnitMeasure_SizeUnitMeasureCode FOREIGN KEY (SizeUnitMeasureCode) REFERENCES Production.UnitMeasure(UnitMeasureCode),
	CONSTRAINT FK_Product_UnitMeasure_WeightUnitMeasureCode FOREIGN KEY (WeightUnitMeasureCode) REFERENCES Production.UnitMeasure(UnitMeasureCode),
	CONSTRAINT FK_Product_ProductModel_ProductModelID FOREIGN KEY (ProductModelID) REFERENCES Production.ProductModel(ProductModelID),
	CONSTRAINT FK_Product_ProductSubcategory_ProductSubcategoryID FOREIGN KEY (ProductSubcategoryID) REFERENCES Production.ProductSubcategory(ProductSubcategoryID);

ALTER TABLE Production.ProductCostHistory ADD
	CONSTRAINT FK_ProductCostHistory_Product_ProductID FOREIGN KEY (ProductID) REFERENCES Production.Product(ProductID);

ALTER TABLE Production.ProductDocument ADD
	CONSTRAINT FK_ProductDocument_Product_ProductID FOREIGN KEY (ProductID) REFERENCES Production.Product(ProductID),
	CONSTRAINT FK_ProductDocument_Document_DocumentNode FOREIGN KEY (DocumentNode) REFERENCES Production.Document(DocumentNode);

ALTER TABLE Production.ProductInventory ADD
	CONSTRAINT FK_ProductInventory_Location_LocationID FOREIGN KEY (LocationID) REFERENCES Production.Location(LocationID),
	CONSTRAINT FK_ProductInventory_Product_ProductID FOREIGN KEY (ProductID) REFERENCES Production.Product(ProductID);

ALTER TABLE Production.ProductListPriceHistory ADD
	CONSTRAINT FK_ProductListPriceHistory_Product_ProductID FOREIGN KEY (ProductID) REFERENCES Production.Product(ProductID);

ALTER TABLE Production.ProductModelIllustration ADD
	CONSTRAINT FK_ProductModelIllustration_ProductModel_ProductModelID FOREIGN KEY (ProductModelID) REFERENCES Production.ProductModel(ProductModelID),
	CONSTRAINT FK_ProductModelIllustration_Illustration_IllustrationID FOREIGN KEY (IllustrationID) REFERENCES Production.Illustration(IllustrationID);

ALTER TABLE Production.ProductModelProductDescriptionCulture ADD
	CONSTRAINT FK_ProductModelProductDescriptionCulture_ProductDescription_ProductDescriptionID FOREIGN KEY (ProductDescriptionID) REFERENCES Production.ProductDescription(ProductDescriptionID),
	CONSTRAINT FK_ProductModelProductDescriptionCulture_Culture_CultureID FOREIGN KEY (CultureID) REFERENCES Production.Culture(CultureID),
	CONSTRAINT FK_ProductModelProductDescriptionCulture_ProductModel_ProductModelID FOREIGN KEY (ProductModelID) REFERENCES Production.ProductModel(ProductModelID);

ALTER TABLE Production.ProductProductPhoto ADD
	CONSTRAINT FK_ProductProductPhoto_Product_ProductID FOREIGN KEY (ProductID) REFERENCES Production.Product(ProductID),
	CONSTRAINT FK_ProductProductPhoto_ProductPhoto_ProductPhotoID FOREIGN KEY (ProductPhotoID) REFERENCES Production.ProductPhoto(ProductPhotoID);

ALTER TABLE Production.ProductReview ADD
	CONSTRAINT FK_ProductReview_Product_ProductID FOREIGN KEY (ProductID) REFERENCES Production.Product(ProductID);

ALTER TABLE Production.ProductSubcategory ADD
	CONSTRAINT FK_ProductSubcategory_ProductCategory_ProductCategoryID FOREIGN KEY (ProductCategoryID) REFERENCES Production.ProductCategory(ProductCategoryID);

ALTER TABLE Purchasing.ProductVendor ADD
	CONSTRAINT FK_ProductVendor_Product_ProductID FOREIGN KEY (ProductID) REFERENCES Production.Product(ProductID),
	CONSTRAINT FK_ProductVendor_UnitMeasure_UnitMeasureCode FOREIGN KEY (UnitMeasureCode) REFERENCES Production.UnitMeasure(UnitMeasureCode),
	CONSTRAINT FK_ProductVendor_Vendor_BusinessEntityID FOREIGN KEY (BusinessEntityID) REFERENCES Purchasing.Vendor(BusinessEntityID);

ALTER TABLE Purchasing.PurchaseOrderDetail ADD
	CONSTRAINT FK_PurchaseOrderDetail_Product_ProductID FOREIGN KEY (ProductID) REFERENCES Production.Product(ProductID),
	CONSTRAINT FK_PurchaseOrderDetail_PurchaseOrderHeader_PurchaseOrderID FOREIGN KEY (PurchaseOrderID) REFERENCES Purchasing.PurchaseOrderHeader(PurchaseOrderID);

ALTER TABLE Purchasing.PurchaseOrderHeader ADD
	CONSTRAINT FK_PurchaseOrderHeader_Employee_EmployeeID FOREIGN KEY (EmployeeID) REFERENCES HumanResources.Employee(BusinessEntityID),
	CONSTRAINT FK_PurchaseOrderHeader_Vendor_VendorID FOREIGN KEY (VendorID) REFERENCES Purchasing.Vendor(BusinessEntityID),
	CONSTRAINT FK_PurchaseOrderHeader_ShipMethod_ShipMethodID FOREIGN KEY (ShipMethodID) REFERENCES Purchasing.ShipMethod(ShipMethodID);

ALTER TABLE Sales.SalesOrderDetail ADD
	CONSTRAINT FK_SalesOrderDetail_SalesOrderHeader_SalesOrderID FOREIGN KEY (SalesOrderID) REFERENCES Sales.SalesOrderHeader(SalesOrderID) ON DELETE CASCADE,
	CONSTRAINT FK_SalesOrderDetail_SpecialOfferProduct_SpecialOfferIDProductID FOREIGN KEY (SpecialOfferID,ProductID) REFERENCES Sales.SpecialOfferProduct(SpecialOfferID,ProductID);

ALTER TABLE Sales.SalesOrderHeader ADD
	CONSTRAINT FK_SalesOrderHeader_Address_BillToAddressID FOREIGN KEY (BillToAddressID) REFERENCES Person.Address(AddressID),
	CONSTRAINT FK_SalesOrderHeader_Address_ShipToAddressID FOREIGN KEY (ShipToAddressID) REFERENCES Person.Address(AddressID),
	CONSTRAINT FK_SalesOrderHeader_CreditCard_CreditCardID FOREIGN KEY (CreditCardID) REFERENCES Sales.CreditCard(CreditCardID),
	CONSTRAINT FK_SalesOrderHeader_CurrencyRate_CurrencyRateID FOREIGN KEY (CurrencyRateID) REFERENCES Sales.CurrencyRate(CurrencyRateID),
	CONSTRAINT FK_SalesOrderHeader_Customer_CustomerID FOREIGN KEY (CustomerID) REFERENCES Sales.Customer(CustomerID),
	CONSTRAINT FK_SalesOrderHeader_SalesPerson_SalesPersonID FOREIGN KEY (SalesPersonID) REFERENCES Sales.SalesPerson(BusinessEntityID),
	CONSTRAINT FK_SalesOrderHeader_ShipMethod_ShipMethodID FOREIGN KEY (ShipMethodID) REFERENCES Purchasing.ShipMethod(ShipMethodID),
	CONSTRAINT FK_SalesOrderHeader_SalesTerritory_TerritoryID FOREIGN KEY (TerritoryID) REFERENCES Sales.SalesTerritory(TerritoryID);

ALTER TABLE Sales.SalesOrderHeaderSalesReason ADD
	CONSTRAINT FK_SalesOrderHeaderSalesReason_SalesReason_SalesReasonID FOREIGN KEY (SalesReasonID) REFERENCES Sales.SalesReason(SalesReasonID),
	CONSTRAINT FK_SalesOrderHeaderSalesReason_SalesOrderHeader_SalesOrderID FOREIGN KEY (SalesOrderID) REFERENCES Sales.SalesOrderHeader(SalesOrderID) ON DELETE CASCADE;

ALTER TABLE Sales.SalesPerson ADD
	CONSTRAINT FK_SalesPerson_Employee_BusinessEntityID FOREIGN KEY (BusinessEntityID) REFERENCES HumanResources.Employee(BusinessEntityID),
	CONSTRAINT FK_SalesPerson_SalesTerritory_TerritoryID FOREIGN KEY (TerritoryID) REFERENCES Sales.SalesTerritory(TerritoryID);

ALTER TABLE Sales.SalesPersonQuotaHistory ADD
	CONSTRAINT FK_SalesPersonQuotaHistory_SalesPerson_BusinessEntityID FOREIGN KEY (BusinessEntityID) REFERENCES Sales.SalesPerson(BusinessEntityID);

ALTER TABLE Sales.SalesTaxRate ADD
	CONSTRAINT FK_SalesTaxRate_StateProvince_StateProvinceID FOREIGN KEY (StateProvinceID) REFERENCES Person.StateProvince(StateProvinceID);

ALTER TABLE Sales.SalesTerritory ADD
	CONSTRAINT FK_SalesTerritory_CountryRegion_CountryRegionCode FOREIGN KEY(CountryRegionCode) REFERENCES Person.CountryRegion (CountryRegionCode);

ALTER TABLE Sales.SalesTerritoryHistory ADD
	CONSTRAINT FK_SalesTerritoryHistory_SalesPerson_BusinessEntityID FOREIGN KEY (BusinessEntityID) REFERENCES Sales.SalesPerson(BusinessEntityID),
	CONSTRAINT FK_SalesTerritoryHistory_SalesTerritory_TerritoryID FOREIGN KEY (TerritoryID) REFERENCES Sales.SalesTerritory(TerritoryID);

ALTER TABLE Sales.ShoppingCartItem ADD
	CONSTRAINT FK_ShoppingCartItem_Product_ProductID FOREIGN KEY (ProductID) REFERENCES Production.Product(ProductID);

ALTER TABLE Sales.SpecialOfferProduct ADD
	CONSTRAINT FK_SpecialOfferProduct_Product_ProductID FOREIGN KEY (ProductID) REFERENCES Production.Product(ProductID),
	CONSTRAINT FK_SpecialOfferProduct_SpecialOffer_SpecialOfferID FOREIGN KEY (SpecialOfferID) REFERENCES Sales.SpecialOffer(SpecialOfferID);

ALTER TABLE Person.StateProvince ADD
	CONSTRAINT FK_StateProvince_CountryRegion_CountryRegionCode FOREIGN KEY (CountryRegionCode) REFERENCES Person.CountryRegion(CountryRegionCode), 
	CONSTRAINT FK_StateProvince_SalesTerritory_TerritoryID FOREIGN KEY (TerritoryID) REFERENCES Sales.SalesTerritory(TerritoryID);

ALTER TABLE Sales.Store ADD
	CONSTRAINT FK_Store_BusinessEntity_BusinessEntityID FOREIGN KEY(BusinessEntityID) REFERENCES Person.BusinessEntity(BusinessEntityID),
	CONSTRAINT FK_Store_SalesPerson_SalesPersonID FOREIGN KEY (SalesPersonID) REFERENCES Sales.SalesPerson(BusinessEntityID);

ALTER TABLE Production.TransactionHistory ADD
	CONSTRAINT FK_TransactionHistory_Product_ProductID FOREIGN KEY (ProductID) REFERENCES Production.Product(ProductID);

ALTER TABLE Purchasing.Vendor ADD
	CONSTRAINT FK_Vendor_BusinessEntity_BusinessEntityID FOREIGN KEY(BusinessEntityID) REFERENCES Person.BusinessEntity(BusinessEntityID);

ALTER TABLE Production.WorkOrder ADD
	CONSTRAINT FK_WorkOrder_Product_ProductID FOREIGN KEY (ProductID) REFERENCES Production.Product(ProductID),
	CONSTRAINT FK_WorkOrder_ScrapReason_ScrapReasonID FOREIGN KEY (ScrapReasonID) REFERENCES Production.ScrapReason(ScrapReasonID);

ALTER TABLE Production.WorkOrderRouting ADD
	CONSTRAINT FK_WorkOrderRouting_Location_LocationID FOREIGN KEY (LocationID) REFERENCES Production.Location(LocationID),
	CONSTRAINT FK_WorkOrderRouting_WorkOrder_WorkOrderID FOREIGN KEY (WorkOrderID) REFERENCES Production.WorkOrder(WorkOrderID);


-- ******************************************************
-- Add database views.
-- ******************************************************
CREATE VIEW Person.vAdditionalContactInfo AS
	SELECT	p.BusinessEntityID,
			p.FirstName,
			p.MiddleName,
			p.LastName,
			TRIM(aci.TelephoneNumber) AS TelephoneNumber,
			TRIM(aci.TelephoneSpecialInstructions) AS TelephoneSpecialInstructions,
			TRIM(aci.Street) AS Street,
			TRIM(aci.City) AS City,
			TRIM(aci.StateProvince) AS StateProvince,
			TRIM(aci.PostalCode) AS PostalCode,
			TRIM(aci.CountryRegion) AS CountryRegion,
			TRIM(aci.HomeAddressSpecialInstructions) AS HomeAddressSpecialInstructions,
			TRIM(aci.EMailAddress) AS EMailAddress,
			TRIM(aci.EMailSpecialInstructions) AS EMailSpecialInstructions,
			TRIM(aci.EMailTelephoneNumber) AS EMailTelephoneNumber,
			p.rowguid,
			p.ModifiedDate
	FROM	Person.Person p
	CROSS JOIN XMLTABLE(XMLNAMESPACES('http://schemas.microsoft.com/sqlserver/2004/07/adventure-works/ContactInfo' AS ci,
									 'http://schemas.microsoft.com/sqlserver/2004/07/adventure-works/ContactTypes' AS act),
						'ci:AdditionalContactInfo' 
						PASSING p.AdditionalContactInfo
						COLUMNS
							TelephoneNumber varchar(50) PATH 'act:telephoneNumber/act:number',
							TelephoneSpecialInstructions text PATH 'act:telephoneNumber/act:SpecialInstructions',
							Street varchar(50) PATH 'act:homePostalAddress/act:Street',
							City varchar(50) PATH 'act:homePostalAddress/act:City',
							StateProvince varchar(50) PATH 'act:homePostalAddress/act:StateProvince',
							PostalCode varchar(50) PATH 'act:homePostalAddress/act:PostalCode',
							CountryRegion varchar(50) PATH 'act:homePostalAddress/act:CountryRegion',
							HomeAddressSpecialInstructions text PATH 'act:homePostalAddress/act:SpecialInstructions',
							EMailAddress varchar(128) PATH 'act:eMail/act:eMailAddress',
							EMailSpecialInstructions text PATH 'act:eMail/act:SpecialInstructions',
							EMailTelephoneNumber varchar(50) PATH 'act:eMail/act:SpecialInstructions/act:telephoneNumber/act:number'
						) AS aci
	WHERE	p.AdditionalContactInfo IS NOT NULL;

CREATE VIEW HumanResources.vEmployee AS
	SELECT	e.BusinessEntityID,
			p.Title,
			p.FirstName,
			p.MiddleName,
			p.LastName,
			p.Suffix,
			e.JobTitle  ,
			pp.PhoneNumber,
			pnt.Name AS PhoneNumberType,
			ea.EmailAddress,
			p.EmailPromotion,
			a.AddressLine1,
			a.AddressLine2,
			a.City,
			sp.Name AS StateProvinceName,
			a.PostalCode,
			cr.Name AS CountryRegionName,
			p.AdditionalContactInfo
	FROM	HumanResources.Employee e
	INNER JOIN Person.Person p
		ON	p.BusinessEntityID = e.BusinessEntityID
    INNER JOIN Person.BusinessEntityAddress bea 
		ON	bea.BusinessEntityID = e.BusinessEntityID 
    INNER JOIN Person.Address a 
		ON	a.AddressID = bea.AddressID
    INNER JOIN Person.StateProvince sp 
		ON	sp.StateProvinceID = a.StateProvinceID
    INNER JOIN Person.CountryRegion cr 
		ON	cr.CountryRegionCode = sp.CountryRegionCode
    LEFT OUTER JOIN Person.PersonPhone pp
		ON	pp.BusinessEntityID = p.BusinessEntityID
    LEFT OUTER JOIN Person.PhoneNumberType pnt
		ON	pnt.PhoneNumberTypeID = pp.PhoneNumberTypeID
    LEFT OUTER JOIN Person.EmailAddress ea
		ON	ea.BusinessEntityID = p.BusinessEntityID;

CREATE VIEW HumanResources.vEmployeeDepartment AS
	SELECT	e.BusinessEntityID,
			p.Title,
			p.FirstName,
			p.MiddleName,
			p.LastName,
			p.Suffix,
			e.JobTitle,
			d.Name AS Department,
			d.GroupName,
			edh.StartDate
	FROM	HumanResources.Employee e
	INNER JOIN Person.Person p
		ON	p.BusinessEntityID = e.BusinessEntityID
    INNER JOIN HumanResources.EmployeeDepartmentHistory edh
		ON	edh.BusinessEntityID = e.BusinessEntityID
		AND edh.EndDate IS NULL
    INNER JOIN HumanResources.Department d
		ON	d.DepartmentID = edh.DepartmentID;

CREATE VIEW HumanResources.vEmployeeDepartmentHistory AS
	SELECT	e.BusinessEntityID,
			p.Title,
			p.FirstName,
			p.MiddleName,
			p.LastName,
			p.Suffix,
			s.Name AS Shift,
			d.Name AS Department,
			d.GroupName,
			edh.StartDate,
			edh.EndDate
	FROM	HumanResources.Employee e
	INNER JOIN Person.Person p
		ON	p.BusinessEntityID = e.BusinessEntityID
	INNER JOIN HumanResources.EmployeeDepartmentHistory edh
		ON	edh.BusinessEntityID = e.BusinessEntityID
	INNER JOIN HumanResources.Department d
		ON	d.DepartmentID = edh.DepartmentID
	INNER JOIN HumanResources.Shift s
		ON	s.ShiftID = edh.ShiftID;

CREATE VIEW Sales.vIndividualCustomer AS
	SELECT	p.BusinessEntityID,
			p.Title,
			p.FirstName,
			p.MiddleName,
			p.LastName,
			p.Suffix,
			pp.PhoneNumber,
			pnt.Name AS PhoneNumberType,
			ea.EmailAddress,
			p.EmailPromotion,
			at.Name AS AddressType,
			a.AddressLine1,
			a.AddressLine2,
			a.City,
			sp.Name AS StateProvinceName,
			a.PostalCode,
			cr.Name AS CountryRegionName
			p.Demographics
	FROM	Person.Person p
	INNER JOIN Person.BusinessEntityAddress bea
		ON	bea.BusinessEntityID = p.BusinessEntityID
	INNER JOIN Person.Address a
		ON	a.AddressID = bea.AddressID
	INNER JOIN Person.StateProvince sp 
		ON	sp.StateProvinceID = a.StateProvinceID
	INNER JOIN Person.CountryRegion cr
		ON	cr.CountryRegionCode = sp.CountryRegionCode
	INNER JOIN Person.AddressType at
		ON	at.AddressTypeID = bea.AddressTypeID
	INNER JOIN Sales.Customer c
		ON	c.PersonID = p.BusinessEntityID
		AND c.StoreID IS NULL
	LEFT JOIN Person.EmailAddress ea
		ON	ea.BusinessEntityID = p.BusinessEntityID
	LEFT JOIN Person.PersonPhone pp
		ON	pp.BusinessEntityID = p.BusinessEntityID
	LEFT JOIN Person.PhoneNumberType pnt
		ON	pnt.PhoneNumberTypeID = pp.PhoneNumberTypeID;

CREATE VIEW Sales.vPersonDemographics AS
	SELECT	p.BusinessEntityID,
			d.TotalPurchaseYTD,
			REPLACE(d.DateFirstPurchase,'Z','')::date AS DateFirstPurchase,
			REPLACE(d.BirthDate,'Z','')::date AS BirthDate,
			d.MaritalStatus,
			d.YearlyIncome,
			d.Gender,
			d.TotalChildren,
			d.NumberChildrenAtHome,
			d.Education,
			d.Occupation,
			d.HomeOwnerFlag,
			d.NumberCarsOwned
	FROM	Person.Person p
	CROSS JOIN XMLTABLE(XMLNAMESPACES('http://schemas.microsoft.com/sqlserver/2004/07/adventure-works/IndividualSurvey' AS is),
						'is:IndividualSurvey' 
						PASSING p.Demographics
						COLUMNS
							TotalPurchaseYTD numeric(20,4) path 'is:TotalPurchaseYTD',
							DateFirstPurchase varchar(20) path 'is:DateFirstPurchase',
							BirthDate varchar(20) path 'is:BirthDate',
							MaritalStatus char(1) path 'is:MaritalStatus',
							YearlyIncome varchar(30) path 'is:YearlyIncome',
							Gender char(1) path 'is:Gender',
							TotalChildren int path 'is:TotalChildren',
							NumberChildrenAtHome int path 'is:NumberChildrenAtHome',
							Education varchar(30) path 'is:Education',
							Occupation varchar(30) path 'is:Occupation',
							HomeOwnerFlag boolean path 'is:HomeOwnerFlag',
							NumberCarsOwned int path 'is:NumberCarsOwned'
						) AS d
	WHERE	p.Demographics IS NOT NULL;

CREATE VIEW HumanResources.vJobCandidate AS
	SELECT	jc.JobCandidateID,
			jc.BusinessEntityID,
			r.Name.Prefix,
			r.Name.First,
			r.Name.Middle,
			r.Name.Last,
			r.Name.Suffix,
			r.Skills,
			r.Addr.Type,
			r.Addr.Loc.CountryRegion,
			r.Addr.Loc.State,
			r.Addr.Loc.City,
			r.Addr.PostalCode,
			r.EMail,
			r.WebSite,
			jc.ModifiedDate
	FROM	HumanResources.JobCandidate jc
	CROSS JOIN XMLTABLE(XMLNAMESPACES('http://schemas.microsoft.com/sqlserver/2004/07/adventure-works/Resume' AS r),
						'r:Resume' 
						PASSING p.Resume
						COLUMNS
							Name.Prefix varchar(30) path 'r:Name/r:Name.Prefix',
							Name.First varchar(30) path 'r:Name/r:Name.First',
							Name.Middle varchar(30) path 'r:Name/r:Name.Middle',
							Name.Last varchar(30) path 'r:Name/r:Name.Last',
							Name.Suffix varchar(30) path 'r:Name/r:Name.Suffix',
							Skills text path 'r:Skills',
							Addr.Type varchar(30) path 'r:Address/r:Addr.Type',
							Addr.Loc.CountryRegion varchar(100) path 'r:Address/r:Addr.Location/r:Location/r:Loc.CountryRegion',
							Addr.Loc.State varchar(100) path 'r:Address/r:Addr.Location/r:Location/r:Loc.State',
							Addr.Loc.City varchar(100) path 'r:Address/r:Addr.Location/r:Location/r:Loc.City',
							Addr.PostalCode varchar(20) path 'r:Address/r:Addr.PostalCode',
							EMail text path 'r:EMail',
							WebSite text path 'r:WebSite'
						) AS r;

CREATE VIEW HumanResources.vJobCandidateEmployment AS
	SELECT	jc.JobCandidateID,
			REPLACE(r.Emp.StartDate,'Z','')::date AS Emp.StartDate,
 			REPLACE(r.Emp.EndDate,'Z','')::date AS Emp.EndDate,
			r.Emp.OrgName,
			r.Emp.JobTitle,
			r.Emp.Responsibility,
			r.Emp.FunctionCategory,
			r.Emp.IndustryCategory,
			r.Emp.Loc.CountryRegion,
			r.Emp.Loc.State,
			r.Emp.Loc.City
	FROM	HumanResources.JobCandidate jc
	CROSS JOIN XMLTABLE(XMLNAMESPACES('http://schemas.microsoft.com/sqlserver/2004/07/adventure-works/Resume' AS r),
						'r:Resume/r:Employment' 
						PASSING p.Resume
						COLUMNS
							Emp.StartDate varchar(20) path 'r:Emp.StartDate',
							Emp.EndDate varchar(20) path 'r:Emp.EndDate',
							Emp.OrgName varchar(100) path 'r:Emp.OrgName',
							Emp.JobTitle varchar(100) path 'r:Emp.JobTitle',
							Emp.Responsibility text path 'r:Emp.Responsibility',
							Emp.FunctionCategory text path 'r:Emp.FunctionCategory',
							Emp.IndustryCategory text path 'r:Emp.IndustryCategory',
							Emp.Loc.CountryRegion text path 'r:Emp.Location/r:Location/r:Loc.CountryRegion',
							Emp.Loc.State text path 'r:Emp.Location/r:Location/r:Loc.State',
							Emp.Loc.City text path 'r:Emp.Location/r:Location/r:Loc.City'
						) AS r;

CREATE VIEW HumanResources.vJobCandidateEducation AS
	SELECT	jc.JobCandidateID,
			r.Edu.Level,
			REPLACE(r.Edu.StartDate,'Z','')::date AS Edu.StartDate,
			REPLACE(r.Edu.EndDate,'Z','')::date AS Edu.EndDate,
			r.Edu.Degree,
			r.Edu.Major,
			r.Edu.Minor,
			r.Edu.GPA,
			r.Edu.GPAScale,
			r.Edu.School,
			r.Edu.Loc.CountryRegion,
			r.Edu.Loc.State,
			r.Edu.Loc.City
    ,Education.ref.value(N'declare default element namespace http://schemas.microsoft.com/sqlserver/2004/07/adventure-works/Resume; 
        (Edu.Level)1', 'nvarchar(max)') AS Edu.Level
    ,CONVERT(datetime, REPLACE(Education.ref.value(N'declare default element namespace http://schemas.microsoft.com/sqlserver/2004/07/adventure-works/Resume; 
        (Edu.StartDate)1', 'nvarchar(20)') ,'Z', ''), 101) AS Edu.StartDate 
    ,CONVERT(datetime, REPLACE(Education.ref.value(N'declare default element namespace http://schemas.microsoft.com/sqlserver/2004/07/adventure-works/Resume; 
        (Edu.EndDate)1', 'nvarchar(20)') ,'Z', ''), 101) AS Edu.EndDate 
    ,Education.ref.value(N'declare default element namespace http://schemas.microsoft.com/sqlserver/2004/07/adventure-works/Resume; 
        (Edu.Degree)1', 'nvarchar(50)') AS Edu.Degree
    ,Education.ref.value(N'declare default element namespace http://schemas.microsoft.com/sqlserver/2004/07/adventure-works/Resume; 
        (Edu.Major)1', 'nvarchar(50)') AS Edu.Major
    ,Education.ref.value(N'declare default element namespace http://schemas.microsoft.com/sqlserver/2004/07/adventure-works/Resume; 
        (Edu.Minor)1', 'nvarchar(50)') AS Edu.Minor
    ,Education.ref.value(N'declare default element namespace http://schemas.microsoft.com/sqlserver/2004/07/adventure-works/Resume; 
        (Edu.GPA)1', 'nvarchar(5)') AS Edu.GPA
    ,Education.ref.value(N'declare default element namespace http://schemas.microsoft.com/sqlserver/2004/07/adventure-works/Resume; 
        (Edu.GPAScale)1', 'nvarchar(5)') AS Edu.GPAScale
    ,Education.ref.value(N'declare default element namespace http://schemas.microsoft.com/sqlserver/2004/07/adventure-works/Resume; 
        (Edu.School)1', 'nvarchar(100)') AS Edu.School
    ,Education.ref.value(N'declare default element namespace http://schemas.microsoft.com/sqlserver/2004/07/adventure-works/Resume; 
        (Edu.Location/Location/Loc.CountryRegion)1', 'nvarchar(100)') AS Edu.Loc.CountryRegion
    ,Education.ref.value(N'declare default element namespace http://schemas.microsoft.com/sqlserver/2004/07/adventure-works/Resume; 
        (Edu.Location/Location/Loc.State)1', 'nvarchar(100)') AS Edu.Loc.State
    ,Education.ref.value(N'declare default element namespace http://schemas.microsoft.com/sqlserver/2004/07/adventure-works/Resume; 
        (Edu.Location/Location/Loc.City)1', 'nvarchar(100)') AS Edu.Loc.City
FROM HumanResources.JobCandidate jc 
	CROSS JOIN XMLTABLE(XMLNAMESPACES('http://schemas.microsoft.com/sqlserver/2004/07/adventure-works/Resume' AS r),
						'r:Resume/r:Education' 
						PASSING p.Resume
						COLUMNS
							Edu.Level text path 'r:Edu.Level',
							Edu.StartDate varchar(20) path 'r:Edu.StartDate',
							Edu.EndDate varchar(20) path 'r:Edu.EndDate',
							Edu.Degree varchar(50) path 'r:Edu.Degree',
							Edu.Major varchar(50) path 'r:Edu.Major',
							Edu.Minor varchar(50) path 'r:Edu.Minor',
							Edu.GPA varchar(20) path 'r:Edu.GPA',
							Edu.GPAScale varchar(20) path 'r:Edu.GPAScale',
							Edu.School varchar(100) path 'r:Edu.School',
							Edu.Loc.CountryRegion text path 'r:Edu.Location/r:Location/r:Loc.CountryRegion',
							Edu.Loc.State text path 'r:Edu.Location/r:Location/r:Loc.State',
							Edu.Loc.City text path 'r:Edu.Location/r:Location/r:Loc.City'
						) AS r;

CREATE MATERIALIZED VIEW Production.vProductAndDescription AS
	SELECT	p.ProductID,
			p.Name,
			pm.Name AS ProductModel,
			pmx.CultureID,
			pd.Description,
	FROM	Production.Product p
	INNER JOIN Production.ProductModel pm
		ON	pm.ProductModelID = p.ProductModelID
	INNER JOIN Production.ProductModelProductDescriptionCulture pmx
		ON	pmx.ProductModelID = pm.ProductModelID
	INNER JOIN Production.ProductDescription pd
		ON	pd.ProductDescriptionID = pmx.ProductDescriptionID;

CREATE UNIQUE INDEX IX_vProductAndDescription ON Production.vProductAndDescription(CultureID, ProductID);

CREATE VIEW Production.vProductModelCatalogDescription AS
	SELECT	pm.ProductModelID,
			pm.Name,
			pmd.Summary,
			pmd.Manufacturer,
			pmd.Copyright,
			pmd.ProductURL,
			pmd.WarrantyPeriod,
			pmd.WarrantyDescription,
			pmd.NoOfYears,
			pmd.MaintenanceDescription,
			pmd.Wheel,
			pmd.Saddle,
			pmd.Pedal,
			pmd.BikeFrame,
			pmd.Crankset,
			pmd.PictureAngle,
			pmd.PictureSize,
			pmd.ProductPhotoID,
			pmd.Material,
			pmd.Color,
			pmd.ProductLine,
			pmd.Style,
			pmd.RiderExperience,
			pm.rowguid,
			pm.ModifiedDate
	FROM	Production.ProductModel pm
	CROSS JOIN XMLTABLE(XMLNAMESPACES('http://schemas.microsoft.com/sqlserver/2004/07/adventure-works/ProductModelDescription' AS p1,
										'http://schemas.microsoft.com/sqlserver/2004/07/adventure-works/ProductModelWarrAndMain' AS wm,
										'http://www.adventure-works.com/schemas/OtherFeatures' AS wf,
										'http://www.w3.org/1999/xhtml' AS html),
						'p1:ProductDescription' 
						PASSING pm.CatalogDescription
						COLUMNS
							Summary text path 'p1:Summary/html:p',
							Manufacturer text path 'p1:Manufacturer/p1:Name',
							Copyright varchar(30) path 'p1:Manufacturer/p1:Copyright',
							ProductURL varchar(256) path 'p1:Manufacturer/p1:ProductURL',
							WarrantyPeriod varchar(256) path 'p1:Features/wm:Warranty/wm:WarrantyPeriod',
							WarrantyDescription varchar(256) path 'p1:Features/wm:Warranty/wm:Description',
							NoOfYears varchar(256) path 'p1:Features/wm:Maintenance/wm:NoOfYears',
							MaintenanceDescription varchar(256) path 'p1:Features/wm:Maintenance/wm:Description',
							Wheel varchar(256) path 'p1:Features/wf:wheel',
							Saddle varchar(256) path 'p1:Features/wf:saddle',
							Pedal varchar(256) path 'p1:Features/wf:pedal',
							BikeFrame varchar(256) path 'p1:Features/wf:BikeFrame',
							Crankset varchar(256) path 'p1:Features/wf:crankset',
							PictureAngle varchar(256) path 'p1:Picture/p1:Angle',
							PictureSize varchar(256) path 'p1:Picture/p1:Size',
							ProductPhotoID varchar(256) path 'p1:Picture/p1:ProductPhotoID',
							Material varchar(256) path 'p1:Specifications/Material',
							Color varchar(256) path 'p1:Specifications/Color',
							ProductLine varchar(256) path 'p1:Specifications/ProductLine',
							Style varchar(256) path 'p1:Specifications/Style',
							RiderExperience varchar(1024) path 'p1:Specifications/RiderExperience'
						) AS pmd
	WHERE	pm.CatalogDescription IS NOT NULL;

CREATE VIEW Production.vProductModelInstructions AS
	SELECT	pm.ProductModelID,
			pm.Name,
			unnest(xpath('/ns:root/text()[1]', pm.Instructions, array[array['ns','http://schemas.microsoft.com/sqlserver/2004/07/adventure-works/ProductModelManuInstructions']]))::text as Instructions,
			pmmi.LocationID,
			pmmi.SetupHours,
			pmmi.MachineHours,
			pmmi.LaborHours,
			pmmi.LotSize,
			pmmi.Step,
			rowguid,
			ModifiedDate
	FROM	Production.ProductModel pm
	CROSS JOIN XMLTABLE(XMLNAMESPACES('http://schemas.microsoft.com/sqlserver/2004/07/adventure-works/ProductModelManuInstructions' AS ns),
						'ns:root/ns:Location/ns:step'
						PASSING pm.Instructions
						COLUMNS
							LocationID int path '../@LocationID',
							SetupHours decimal(9, 4) path '../@SetupHours',
							MachineHours decimal(9, 4) path '../@MachineHours',
							LaborHours decimal(9, 4) path '../@LaborHours',
							LotSize int path '../@LotSize',
							Step text path 'string(.)'
						) AS pmmi;

CREATE VIEW Sales.vSalesPerson AS
	SELECT	s.BusinessEntityID,
			p.Title,
			p.FirstName,
			p.MiddleName,
			p.LastName,
			p.Suffix,
			e.JobTitle,
			pp.PhoneNumber,
			pnt.Name AS PhoneNumberType,
			ea.EmailAddress,
			p.EmailPromotion,
			a.AddressLine1,
			a.AddressLine2,
			a.City,
			sp.Name AS StateProvinceName,
			a.PostalCode,
			cr.Name AS CountryRegionName,
			st.Name AS TerritoryName,
			st.Group AS TerritoryGroup,
			s.SalesQuota,
			s.SalesYTD,
			s.SalesLastYear
	FROM	Sales.SalesPerson s
	INNER JOIN HumanResources.Employee e 
		ON	e.BusinessEntityID = s.BusinessEntityID
	INNER JOIN Person.Person p
		ON	p.BusinessEntityID = s.BusinessEntityID
	INNER JOIN Person.BusinessEntityAddress bea 
		ON	bea.BusinessEntityID = s.BusinessEntityID 
	INNER JOIN Person.Address a 
		ON	a.AddressID = bea.AddressID
	INNER JOIN Person.StateProvince sp 
		ON	sp.StateProvinceID = a.StateProvinceID
	INNER JOIN Person.CountryRegion cr 
		ON	cr.CountryRegionCode = sp.CountryRegionCode
	LEFT JOIN Sales.SalesTerritory st 
		ON	st.TerritoryID = s.TerritoryID
	LEFT JOIN Person.EmailAddress ea
		ON	ea.BusinessEntityID = p.BusinessEntityID
	LEFT JOIN Person.PersonPhone pp
		ON	pp.BusinessEntityID = p.BusinessEntityID
	LEFT JOIN Person.PhoneNumberType pnt
		ON	pnt.PhoneNumberTypeID = pp.PhoneNumberTypeID;

CREATE VIEW Sales.vSalesPersonSalesByFiscalYears AS
	SELECT	soh.SalesPersonID,
			CONCAT_WS(' ', p.FirstName, p.MiddleName, p.LastName) AS FullName,
			e.JobTitle,
			st.Name AS SalesTerritory,
			s.2002,
			s.2003,
			s.2004
	FROM	Sales.SalesPerson sp 
	INNER JOIN CROSSTAB('SELECT	SalesPersonID, EXTRACT(YEAR FROM (OrderDate + interval ''6 months'')::date) AS FiscalYear,  SubTotal
						 FROM	Sales.SalesOrderHeader
						 ORDER BY 1,2') AS s(SalesPersonID int, 2002 numeric(20,4), 2003 numeric(20,4), 2004 numeric(20,4))
		ON	soh.SalesPersonID = sp.BusinessEntityID
	INNER JOIN Sales.SalesTerritory st
		ON	st.TerritoryID = sp.TerritoryID
	INNER JOIN HumanResources.Employee e
		ON	e.BusinessEntityID = soh.SalesPersonID
	INNER JOIN Person.Person p
		ON	p.BusinessEntityID = sp.BusinessEntityID;

CREATE VIEW Person.vStateProvinceCountryRegion 
AS 
	SELECT	sp.StateProvinceID,
			sp.StateProvinceCode,
			sp.IsOnlyStateProvinceFlag,
			sp.Name AS StateProvinceName,
			sp.TerritoryID,
			cr.CountryRegionCode,
			cr.Name AS CountryRegionName
	FROM	Person.StateProvince sp 
	INNER JOIN Person.CountryRegion cr 
		ON	cr.CountryRegionCode = sp.CountryRegionCode;

CREATE VIEW Sales.vStoreWithDemographics AS 
	SELECT	s.BusinessEntityID,
			s.Name,
			d.AnnualSales,
			d.AnnualRevenue,
			d.BankName,
			d.BusinessType,
			d.YearOpened,
			d.Specialty,
			d.SquareFeet,
			d.Brands,
			d.Internet,
			d.NumberEmployees
	FROM	Sales.Store s
	CROSS JOIN XMLTABLE(XMLNAMESPACES('http://schemas.microsoft.com/sqlserver/2004/07/adventure-works/StoreSurvey' AS ns),
						'ns:StoreSurvey'
						PASSING s.Demographics
						COLUMNS
							AnnualSales numeric(20,4) path '/AnnualSales',
							AnnualRevenue numeric(20, 4) path '/AnnualRevenue',
							BankName varchar(50) path '/BankName',
							BusinessType varchar(5) path '/BusinessType',
							YearOpened int path '/YearOpened',
							Specialty varchar(50) path '/Specialty',
							SquareFeet int path '/SquareFeet',
							Brands varchar(30) path '/Brands',
							Internet varchar(30) path '/Internet',
							NumberEmployees int path '/NumberEmployees'
						) AS d;

CREATE VIEW Sales.vStoreWithContacts AS
	SELECT	s.BusinessEntityID,
			s.Name,
			ct.Name AS ContactType,
			p.Title,
			p.FirstName,
			p.MiddleName,
			p.LastName,
			p.Suffix,
			pp.PhoneNumber,
			pnt.Name AS PhoneNumberType,
			ea.EmailAddress,
			p.EmailPromotion
	FROM	Sales.Store s
	INNER JOIN Person.BusinessEntityContact bec 
		ON	bec.BusinessEntityID = s.BusinessEntityID
	INNER JOIN Person.ContactType ct
		ON	ct.ContactTypeID = bec.ContactTypeID
	INNER JOIN Person.Person p
		ON	p.BusinessEntityID = bec.PersonID
	LEFT JOIN Person.EmailAddress ea
		ON	ea.BusinessEntityID = p.BusinessEntityID
	LEFT JOIN Person.PersonPhone pp
		ON	pp.BusinessEntityID = p.BusinessEntityID
	LEFT JOIN Person.PhoneNumberType pnt
		ON	pnt.PhoneNumberTypeID = pp.PhoneNumberTypeID;

CREATE VIEW Sales.vStoreWithAddresses AS
	SELECT	s.BusinessEntityID,
			s.Name,
			at.Name AS AddressType,
			a.AddressLine1,
			a.AddressLine2,
			a.City,
			sp.Name AS StateProvinceName,
			a.PostalCode,
			cr.Name AS CountryRegionName
	FROM	Sales.Store s
	INNER JOIN Person.BusinessEntityAddress bea 
		ON	bea.BusinessEntityID = s.BusinessEntityID 
	INNER JOIN Person.Address a 
		ON	a.AddressID = bea.AddressID
	INNER JOIN Person.StateProvince sp 
		ON	sp.StateProvinceID = a.StateProvinceID
	INNER JOIN Person.CountryRegion cr 
		ON	cr.CountryRegionCode = sp.CountryRegionCode
	INNER JOIN Person.AddressType at 
		ON	at.AddressTypeID = bea.AddressTypeID;

CREATE VIEW Purchasing.vVendorWithContacts AS
	SELECT	v.BusinessEntityID,
			v.Name,
			ct.Name AS ContactType,
			p.Title,
			p.FirstName,
			p.MiddleName,
			p.LastName,
			p.Suffix,
			pp.PhoneNumber,
			,pnt.Name AS PhoneNumberType,
			ea.EmailAddress,
			p.EmailPromotion
	FROM	Purchasing.Vendor v
	INNER JOIN Person.BusinessEntityContact bec 
		ON	bec.BusinessEntityID = v.BusinessEntityID
	INNER JOIN Person.ContactType ct
		ON	ct.ContactTypeID = bec.ContactTypeID
	INNER JOIN Person.Person p
		ON	p.BusinessEntityID = bec.PersonID
	LEFT JOIN Person.EmailAddress ea
		ON	ea.BusinessEntityID = p.BusinessEntityID
	LEFT JOIN Person.PersonPhone pp
		ON	pp.BusinessEntityID = p.BusinessEntityID
	LEFT JOIN Person.PhoneNumberType pnt
		ON	pnt.PhoneNumberTypeID = pp.PhoneNumberTypeID;

CREATE VIEW Purchasing.vVendorWithAddresses AS
	SELECT	v.BusinessEntityID
			v.Name
			at.Name AS AddressType
			a.AddressLine1 
			a.AddressLine2 
			a.City 
			sp.Name AS StateProvinceName 
			a.PostalCode 
			cr.Name AS CountryRegionName 
	FROM	Purchasing.Vendor v
	INNER JOIN Person.BusinessEntityAddress bea 
		ON	bea.BusinessEntityID = v.BusinessEntityID 
	INNER JOIN Person.Address a 
		ON	a.AddressID = bea.AddressID
	INNER JOIN Person.StateProvince sp 
		ON	sp.StateProvinceID = a.StateProvinceID
	INNER JOIN Person.CountryRegion cr 
		ON	cr.CountryRegionCode = sp.CountryRegionCode
	INNER JOIN Person.AddressType at 
		ON	at.AddressTypeID = bea.AddressTypeID;

-- ******************************************************
-- Add database functions and stored procedures
-- ******************************************************
CREATE OR REPLACE FUNCTION dbo.ufnGetAccountingStartDate()
	RETURNS timestamp
	IMMUTABLE
	LANGUAGE PLPGSQL
AS $function$
BEGIN
	RETURN '2003-07-01 00:00:00'::timestamp;
END;
$function$;

CREATE OR REPLACE FUNCTION dbo.ufnGetAccountingEndDate()
	RETURNS timestamp
	IMMUTABLE
	LANGUAGE PLPGSQL
AS $function$
BEGIN
	RETURN '2004-07-01 00:00:00'::timestamp - (INTERVAL '5 ms');
END;
$function$;

CREATE OR REPLACE FUNCTION dbo.ufnGetContactInformation(p_PersonID int)
	RETURNS TABLE (
		-- Columns returned by the function
		PersonID int NOT NULL,
		FirstName varchar(50) NULL,
		LastName varchar(50) NULL,
		JobTitle varchar(50) NULL,
		BusinessEntityType varchar(50) NULL
		)
	STABLE
	LANGUAGE SQL
AS $function$
-- Returns the first name, last name, job title and business entity type for the specified contact.
-- Since a contact can serve multiple roles, more than one row may be returned.
	SELECT	e.BusinessEntityID, p.FirstName, p.LastName, e.JobTitle, 'Employee'
	FROM	HumanResources.Employee AS e
	INNER JOIN Person.Person p
		ON	p.BusinessEntityID = e.BusinessEntityID
	WHERE	e.BusinessEntityID = p_PersonID

	UNION ALL

	SELECT	bec.PersonID, p.FirstName, p.LastName, ct.Name, 'Vendor Contact'
	FROM	Purchasing.Vendor AS v
	INNER JOIN Person.BusinessEntityContact bec
		ON	bec.BusinessEntityID = v.BusinessEntityID
		AND bec.PersonID = p_PersonID
	INNER JOIN Person.ContactType ct
		ON	ct.ContactTypeID = bec.ContactTypeID
	INNER JOIN Person.Person p
		ON	p.BusinessEntityID = bec.PersonID

	UNION ALL

	SELECT	bec.PersonID, p.FirstName, p.LastName, ct.Name, 'Store Contact'
	FROM	Sales.Store AS s
	INNER JOIN Person.BusinessEntityContact bec
		ON	bec.BusinessEntityID = s.BusinessEntityID
		AND bec.PersonID = p_PersonID
	INNER JOIN Person.ContactType ct
		ON	ct.ContactTypeID = bec.ContactTypeID
	INNER JOIN Person.Person p
		ON	p.BusinessEntityID = bec.PersonID

	UNION ALL

	SELECT	p.BusinessEntityID, p.FirstName, p.LastName, NULL, 'Consumer'
	FROM	Person.Person AS p
	INNER JOIN Sales.Customer AS c
		ON	c.PersonID = p.BusinessEntityID
		AND c.StoreID IS NULL
	WHERE	p.BusinessEntityID = p_PersonID
	;
$function$;


CREATE OR REPLACE FUNCTION dbo.ufnGetProductDealerPrice(p_ProductID int, p_OrderDate date)
	RETURNS numeric(20,4)
	STABLE
	LANGUAGE PLPGSQL
AS $function$
DECLARE
	v_DealerPrice numeric(20,4);
	v_DealerDiscount CONSTANT numeric(20,4) := 0.60; -- 60% of list price
-- Returns the dealer price for the product on a specific date.
BEGIN
	SELECT	plph.ListPrice * v_DealerDiscount
	INTO	v_DealerPrice
	FROM	Production.Product p
	INNER JOIN Production.ProductListPriceHistory plph
		ON	plph.ProductID = p.ProductID
	WHERE	p.ProductID = p_ProductID
		AND p_OrderDate BETWEEN plph.StartDate AND COALESCE(plph.EndDate, '9999-12-31'::date); -- Make sure we get all the prices!

	RETURN	v_DealerPrice;
END;
$function$;

CREATE OR REPLACE FUNCTION dbo.ufnGetProductListPrice(p_ProductID int, p_OrderDate date)
	RETURNS numeric(20,4)
	STABLE
	LANGUAGE SQL
AS $function$
	SELECT	plph.ListPrice
	FROM	Production.Product p
	INNER JOIN Production.ProductListPriceHistory plph
		ON	plph.ProductID = p.ProductID
	WHERE	p.ProductID = p_ProductID
		AND p_OrderDate BETWEEN plph.StartDate AND COALESCE(plph.EndDate, '9999-12-31'::date); -- Make sure we get all the prices!
$function$;

CREATE OR REPLACE FUNCTION dbo.ufnGetProductStandardCost(p_ProductID int, p_OrderDate date)
	RETURNS numeric(20,4)
	STABLE
	LANGUAGE SQL
AS $function$
-- Returns the standard cost for the product on a specific date.
	SELECT	pch.StandardCost
	FROM	Production.Product p
	INNER JOIN Production.ProductCostHistory pch
		ON	pch.ProductID = p.ProductID
	WHERE	p.ProductID = p_ProductID
		AND p_OrderDate BETWEEN plph.StartDate AND COALESCE(plph.EndDate, '9999-12-31'::date); -- Make sure we get all the prices!
$function$;

CREATE OR REPLACE FUNCTION dbo.ufnGetStock(p_ProductID int)
	RETURNS int
	STABLE
	LANGUAGE SQL
AS $function$
-- Returns the stock level for the product. This function is used internally only
	SELECT	COALESCE(SUM(p.Quantity),0)
	FROM	Production.ProductInventory p
	WHERE	p.ProductID = p_ProductID
		AND p.LocationID = '6'; -- Only look at inventory in the misc storage
$function$

CREATE OR REPLACE FUNCTION dbo.ufnGetDocumentStatusText(p_Status smallint)
	RETURNS varchar(16)
	IMMUTABLE
	LANGUAGE SQL
AS $function$
-- Returns the sales order status text representation for the status value.
	SELECT	CASE p_Status
				WHEN 1 THEN 'Pending approval'
				WHEN 2 THEN 'Approved'
				WHEN 3 THEN 'Obsolete'
				ELSE '** Invalid **'
			END;
$function$;

CREATE OR REPLACE FUNCTION dbo.ufnGetPurchaseOrderStatusText(p_Status smallint)
	RETURNS varchar(16)
	IMMUTABLE
	LANGUAGE SQL
AS $function$
-- Returns the sales order status text representation for the status value.
	SELECT	CASE p_Status
				WHEN 1 THEN 'Pending'
				WHEN 2 THEN 'Approved'
				WHEN 3 THEN 'Rejected'
				WHEN 4 THEN 'Complete'
				ELSE '** Invalid **'
			END;
$function$;

CREATE OR REPLACE FUNCTION dbo.ufnGetSalesOrderStatusText(p_Status smallint)
	RETURNS varchar(16)
	IMMUTABLE
	LANGUAGE SQL
AS $function$
-- Returns the sales order status text representation for the status value.
	SELECT	CASE p_Status
				WHEN 1 THEN 'In process'
				WHEN 2 THEN 'Approved'
				WHEN 3 THEN 'Backordered'
				WHEN 4 THEN 'Rejected'
				WHEN 5 THEN 'Shipped'
				WHEN 6 THEN 'Cancelled'
				ELSE '** Invalid **'
			END;
$function$;

CREATE OR REPLACE FUNCTION dbo.uspGetBillOfMaterials (p_StartProductID int, p_CheckDate date)
	RETURNS TABLE (
			ProductAssemblyID int,
			ComponentID int,
			ComponentDesc Name,
			TotalQuantity decimal(8,2),
			StandardCost numeric(20,4),
			ListPrice numeric(20,4),
			BOMLevel smallint,
			RecursionLevel smallint
			)
	STABLE
	LANGUAGE SQL
AS $function$
	-- Use recursive query to generate a multi-level Bill of Material (i.e. all level 1 
	-- components of a level 0 assembly, all level 2 components of a level 1 assembly)
	-- The CheckDate eliminates any components that are no longer used in the product on this date.
	WITH RECURSIVE BOM_cte(ProductAssemblyID, ComponentID, ComponentDesc, PerAssemblyQty, StandardCost, ListPrice, BOMLevel, RecursionLevel) AS (-- CTE name and columns
		SELECT	b.ProductAssemblyID, b.ComponentID, p.Name, b.PerAssemblyQty, p.StandardCost, p.ListPrice, b.BOMLevel, 0::smallint -- Get the initial list of components for the bike assembly
		FROM	Production.BillOfMaterials b
		INNER JOIN Production.Product p
			ON	p.ProductID = b.ComponentID
		WHERE	b.ProductAssemblyID = p_StartProductID 
			AND p_CheckDate >= b.StartDate 
			AND p_CheckDate <= COALESCE(b.EndDate, p_CheckDate)
        UNION ALL
		SELECT	b.ProductAssemblyID, b.ComponentID, p.Name, b.PerAssemblyQty, p.StandardCost, p.ListPrice, b.BOMLevel, RecursionLevel + 1::smallint -- Join recursive member to anchor
		FROM	BOM_cte cte
		INNER JOIN Production.BillOfMaterials b
			ON	b.ProductAssemblyID = cte.ComponentID
		INNER JOIN Production.Product p
			ON	p.ProductID = b.ComponentID
		WHERE	p_CheckDate >= b.StartDate
			AND p_CheckDate <= COALESCE(b.EndDate, p_CheckDate)
        )
	-- Outer select from the CTE
	SELECT	b.ProductAssemblyID, b.ComponentID, b.ComponentDesc, SUM(b.PerAssemblyQty) AS TotalQuantity , b.StandardCost, b.ListPrice, b.BOMLevel, b.RecursionLevel
	FROM	BOM_cte b
	GROUP BY b.ComponentID, b.ComponentDesc, b.ProductAssemblyID, b.BOMLevel, b.RecursionLevel, b.StandardCost, b.ListPrice
	ORDER BY b.BOMLevel, b.ProductAssemblyID, b.ComponentID;
$function$;

CREATE OR REPLACE FUNCTION dbo.uspGetEmployeeManagers (p_BusinessEntityID int)
	RETURNS TABLE (
			RecursionLevel smallint,
			BusinessEntityID int,
			FirstName Name,
			LastName Name,
			OrganizationNode text,
			ManagerFirstName Name,
			ManagerLastName Name
			)
	STABLE
	LANGUAGE SQL
AS $function$
	-- Use recursive query to list out all Employees required for a particular Manager
	WITH RECURSIVE EMP_cte(BusinessEntityID, OrganizationNode, FirstName, LastName, JobTitle, RecursionLevel) AS (-- CTE name and columns
		SELECT	e.BusinessEntityID, e.OrganizationNode, p.FirstName, p.LastName, e.JobTitle, 0::smallint -- Get the initial Employee
		FROM	HumanResources.Employee e
		INNER JOIN Person.Person AS p
			ON	p.BusinessEntityID = e.BusinessEntityID
		WHERE	e.BusinessEntityID = p_BusinessEntityID
		UNION ALL
		SELECT	e.BusinessEntityID, e.OrganizationNode, p.FirstName, p.LastName, e.JobTitle, RecursionLevel + 1 -- Join recursive member to anchor
		FROM	HumanResources.Employee e
		INNER JOIN EMP_cte cte
			ON	e.OrganizationNode = SUBPATH(cte.OrganizationNode, 0, -1) -- Parent Node
		INNER JOIN Person.Person p
			ON	p.BusinessEntityID = e.BusinessEntityID
		)
    -- Join back to Employee to return the manager name 
	SELECT	cte.RecursionLevel,
			cte.BusinessEntityID,
			cte.FirstName,
			cte.LastName,
			cte.OrganizationNode::text AS OrganizationNode,
			p.FirstName AS ManagerFirstName,
			p.LastName AS ManagerLastName  -- Outer select from the CTE
	FROM	EMP_cte cte
	INNER JOIN HumanResources.Employee e
		ON	e.OrganizationNode = SUBPATH(cte.OrganizationNode, 0, -1) -- Parent Node
	INNER JOIN Person.Person p
		ON	p.BusinessEntityID = e.BusinessEntityID
	ORDER BY RecursionLevel, cte.OrganizationNode::text;
$function$;

CREATE OR REPLACE FUNCTION dbo.uspGetManagerEmployees (p_BusinessEntityID int)
	RETURNS TABLE (
			RecursionLevel smallint,
			OrganizationNode text,
			ManagerFirstName Name,
			ManagerLastName Name,
			BusinessEntityID int,
			FirstName Name,
			LastName Name
			)
	STABLE
	LANGUAGE SQL
AS $function$
	-- Use recursive query to list out all Employees required for a particular Manager
	WITH RECURSIVE EMP_cte(BusinessEntityID, OrganizationNode, FirstName, LastName, RecursionLevel) AS ( -- CTE name and columns
		SELECT	e.BusinessEntityID, e.OrganizationNode, p.FirstName, p.LastName, 0::smallint -- Get the initial list of Employees for Manager n
		FROM	HumanResources.Employee e 
		INNER JOIN Person.Person p
			ON	p.BusinessEntityID = e.BusinessEntityID
		WHERE	e.BusinessEntityID = p_BusinessEntityID
		UNION ALL
		SELECT	e.BusinessEntityID, e.OrganizationNode, p.FirstName, p.LastName, RecursionLevel + 1::smallint -- Join recursive member to anchor
		FROM	HumanResources.Employee e
		INNER JOIN EMP_cte cte
			ON	cte.OrganizationNode = SUBPATH(e.OrganizationNode, 0, -1) -- Parent Node
		INNER JOIN Person.Person p
			ON	p.BusinessEntityID = e.BusinessEntityID
		WHERE	RecursionLevel < 25
		)
	-- Join back to Employee to return the manager name 
	SELECT	cte.RecursionLevel, cte.OrganizationNode::text as OrganizationNode, p.FirstName AS 'ManagerFirstName', p.LastName AS 'ManagerLastName',
			cte.BusinessEntityID, cte.FirstName, cte.LastName -- Outer select from the CTE
	FROM	EMP_cte cte
	INNER JOIN HumanResources.Employee e
		ON	e.OrganizationNode = SUBPATH(cte.OrganizationNode, 0, -1) -- Parent Node
	INNER JOIN Person.Person p
		ON	p.BusinessEntityID = e.BusinessEntityID
	ORDER BY cte.RecursionLevel, cte.OrganizationNode::text;
$function$;

CREATE OR REPLACE FUNCTION dbo.uspGetWhereUsedProductID(p_StartProductID int, p_CheckDate date)
	RETURNS TABLE (
			ProductAssemblyID int,
			ComponentID int,
			ComponentDesc Name,
			TotalQuantity decimal(8,2),
			StandardCost numeric(20,4),
			ListPrice numeric(20,4),
			BOMLevel smallint,
			RecursionLevel smallint
			)
	STABLE
	LANGUAGE SQL
AS $function$

	--Use recursive query to generate a multi-level Bill of Material (i.e. all level 1 components of a level 0 assembly, all level 2 components of a level 1 assembly)
	WITH RECURSIVE BOM_cte(ProductAssemblyID, ComponentID, ComponentDesc, PerAssemblyQty, StandardCost, ListPrice, BOMLevel, RecursionLevel) AS ( -- CTE name and columns
		SELECT	b.ProductAssemblyID, b.ComponentID, p.Name, b.PerAssemblyQty, p.StandardCost, p.ListPrice, b.BOMLevel, 0::smallint -- Get the initial list of components for the bike assembly
		FROM	Production.BillOfMaterials b
		INNER JOIN Production.Product p
			ON	p.ProductID = b.ProductAssemblyID
		WHERE	b.ComponentID = @StartProductID
			AND p_CheckDate >= b.StartDate
			AND p_CheckDate <= COALESCE(b.EndDate, p_CheckDate)
		UNION ALL
		SELECT	b.ProductAssemblyID, b.ComponentID, p.Name, b.PerAssemblyQty, p.StandardCost, p.ListPrice, b.BOMLevel, RecursionLevel + 1::smallint -- Join recursive member to anchor
		FROM	BOM_cte cte
		INNER JOIN Production.BillOfMaterials b
			ON	b.ComponentID = cte.ProductAssemblyID
		INNER JOIN Production.Product p
			ON	p.ProductID = b.ProductAssemblyID
		WHERE	p_CheckDate >= b.StartDate
			AND p_CheckDate <= COALESCE(b.EndDate, p_CheckDate)
		)
	-- Outer select from the CTE
	SELECT	b.ProductAssemblyID, b.ComponentID, b.ComponentDesc, SUM(b.PerAssemblyQty) AS TotalQuantity , b.StandardCost, b.ListPrice, b.BOMLevel, b.RecursionLevel
	FROM	BOM_cte b
	GROUP BY b.ComponentID, b.ComponentDesc, b.ProductAssemblyID, b.BOMLevel, b.RecursionLevel, b.StandardCost, b.ListPrice
	ORDER BY b.BOMLevel, b.ProductAssemblyID, b.ComponentID;
$function$;

CREATE OR REPLACE PROCEDURE HumanResources.uspUpdateEmployeeHireInfo (
			p_BusinessEntityID int,
			p_JobTitle varchar(50),
			p_HireDate date,
			p_RateChangeDate date,
			p_Rate numeric(20,4),
			p_PayFrequency smallint,
			p_CurrentFlag d_Flag
			)
	VOLATILE
	LANGUAGE PLPGSQL
	SECURITY DEFINER
AS $procedure$
DECLARE
	v_pg_context text;
	v_pg_sqlstate text;
BEGIN
	UPDATE	HumanResources.Employee
		SET JobTitle = p_JobTitle,
			HireDate = p_HireDate,
			CurrentFlag = p_CurrentFlag 
	WHERE	BusinessEntityID = p_BusinessEntityID;

	INSERT INTO HumanResources.EmployeePayHistory (
			BusinessEntityID,
			RateChangeDate,
			Rate,
			PayFrequency
			)
	VALUES	(p_BusinessEntityID, p_RateChangeDate, p_Rate, p_PayFrequency);

EXCEPTION
	GET STACKED DIAGNOSTICS v_pg_context = pg_exception_context,
							v_pg_sqlstate = returned_sqlstate;
	CALL dbo.uspLogError(v_pg_context, v_pg_sqlstate);

END;
$procedure$;

CREATE OR REPLACE PROCEDURE HumanResources.uspUpdateEmployeeLogin (
		p_BusinessEntityID int,
		p_OrganizationNode ltree,
		p_LoginID varchar(256),
		p_JobTitle varchar(50),
		p_HireDate date,
		p_CurrentFlag d_Flag
		)
	VOLATILE
	SECURITY INVOKER
	LANGUAGE PLPGSQL
AS $procedure$
DECLARE
	v_pg_context text;
	v_pg_sqlstate text;
BEGIN
	UPDATE	HumanResources.Employee
		SET OrganizationNode = p_OrganizationNode,
			LoginID = p_LoginID,
			JobTitle = p_JobTitle,
			HireDate = p_HireDate,
			CurrentFlag = p_CurrentFlag
	WHERE	BusinessEntityID = p_BusinessEntityID;

EXCEPTION
	GET STACKED DIAGNOSTICS v_pg_context = pg_exception_context,
							v_pg_sqlstate = returned_sqlstate;
	CALL dbo.uspLogError(v_pg_context, v_pg_sqlstate);
END;
$procedure$;

CREATE OR REPLACE PROCEDURE HumanResources.uspUpdateEmployeePersonalInfo (
		p_BusinessEntityID int,
		p_NationalIDNumber varchar(15),
		p_BirthDate date,
		p_MaritalStatus char(1),
		p_Gender char(1)
		)
	VOLATILE
	SECURITY DEFINER
	LANGUAGE PLPGSQL
AS $procedure$
DECLARE
	v_pg_context text;
	v_pg_sqlstate text;
BEGIN
	UPDATE	HumanResources.Employee
		SET NationalIDNumber = p_NationalIDNumber,
			BirthDate = p_BirthDate,
			MaritalStatus = p_MaritalStatus,
			Gender = p_Gender
	WHERE	BusinessEntityID = p_BusinessEntityID;

EXCEPTION
	GET STACKED DIAGNOSTICS v_pg_context = pg_exception_context,
							v_pg_sqlstate = returned_sqlstate;
	CALL dbo.uspLogError(v_pg_context, v_pg_sqlstate);
END;
$procedure$;

CREATE OR REPLACE FUNCTION dbo.uspSearchCandidateResumes (
		p_searchString varchar(1000),
		p_useInflectional boolean DEFAULT false,
		p_useThesaurus boolean DEFAULT false,
		p_language int DEFAULT 0
		)
	RETURNS TABLE (
		JobCandidateID int
		)
	VOLATILE
	SECURITY DEFINER
	LANGUAGE SQL
AS $function$
	-- Use of Language, Inflectional, and Thesaurus are beyond scope for this exercise
	SELECT	jc.JobCandidateID
	FROM	HumanResources.JobCandidate AS jc
	WHERE	to_tsvector(jc.Resume) @@ to_tsquery(p_searchString);
$function$;